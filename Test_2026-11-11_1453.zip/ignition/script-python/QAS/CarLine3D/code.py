# QAS.CarLine3D
# Event-driven data API + tag model for the Car Body & Final Assembly Line 3D page.
#
# Same architecture as QAS.Line3D (battery line), kept fully separate so neither page can break
# the other (own tag folder, own UDT, own getGlobals() keys):
#
#   * Page + three.js are WebDev TEXT resources under CarLine3D/ (index.html, vendor/...).
#     The page calls the sibling Python resource CarLine3D/data with a RELATIVE url.
#   * CarLine3D/data/doGet is one line that delegates to handleData() below.
#   * CarLine3D/data/doPost delegates to handleCommand(): the line control panel built into the page
#     (run/stop, simulator, speed, target rate, per-station state, reset shift) writes tags through it,
#     so the page needs only the WebDev module - no Perspective session.
#   * Tags live in [default]CarLine:  Line/*  (line-level tags)  and  ST10..ST80  (UDT CarStation).
#     Every member that the page shows has a valueChanged tag event script that bumps a sequence
#     number and signals a Java Condition, so a waiting long-poll GET returns the moment a PLC (or
#     the simulator, or an operator command from the page) changes a tag.
#   * ensureTags() creates the UDT definition and all instances with system.tag.configure() the
#     first time the page connects (or on GET CarLine3D/data?setup=1). It never touches existing tags.
#   * Simulator: while [default]CarLine/Line/SimEnabled is true, the gateway behaves like the line
#     PLC. It is an indexing (pulse) line: every station works its cycle, the line transfers all
#     bodies one pitch when every station is complete, VINs move downstream, faults block upstream
#     and starve downstream. It writes ONLY tags - the page reads them back through the same tag
#     event path it would use with a real PLC. Set SimEnabled false when real PLC tags drive the line.
#     The simulator is pumped from the data endpoint (at most one tick per SIM_TICK_MS across all
#     viewers) and can also be called from a Gateway Timer Script:
#         if system.tag.readBlocking(['[default]CarLine/Line/SimEnabled'])[0].value: QAS.CarLine3D.simTick()

PROVIDER = "[default]"
BASE = PROVIDER + "CarLine"
UDT_NAME = "CarStation"
UDT_PATH = PROVIDER + "_types_/" + UDT_NAME
LINE_KEY = "Line"

LINE_MEMBERS = ["Running", "SimEnabled", "SpeedPct", "JPH", "TargetJPH", "OEE", "Good", "ShiftTarget",
	"IndexCount", "Transfer", "TaktTime", "Andon"]
ST_MEMBERS = ["State", "Progress", "CycleTime", "IdealCycle", "Count", "Rejects", "FaultCode", "FaultText",
	"VIN", "PartPresent", "RobotsActive", "RobotCount", "PV", "PVLow", "PVHigh", "PVName", "PVUnit", "EnergyKW", "StationName", "Mode"]

LOGGER_NAME = "QAS.CarLine3D"
RT_KEY = "qas_carline3d_rt"          # must match the tag event scripts (see EVENT_SCRIPT)
SIM_KEY = "qas_carline3d_sim"
READY_KEY = "qas_carline3d_ready_v2"     # bump to re-run ensureTags()/migrations once

WAIT_DEFAULT_MS = 20000
WAIT_MAX_MS = 25000
SETTLE_MS = 40
SIM_TICK_MS = 1000

ALLOWED_ROLES = []                    # empty = anyone the WebDev resource lets through

STATE_NAMES = {0: "Stopped", 1: "Running", 2: "Idle", 3: "Blocked", 4: "Faulted", 5: "Maintenance"}

# code, name, robots, ideal cycle s, PV name, unit, nominal, low, high, idle PV, idle kW, run kW,
# fault (code, text, PV while faulted)
STATIONS = [
	("ST10", "Underbody Welding", 4, 34.0, "Weld current", "kA", 9.6, 8.6, 10.6, 0.0, 18.0, 145.0,
		(1104, "Weld gun tip dress overdue - current low", 7.9)),
	("ST20", "Body Framing", 4, 38.0, "Framing gap", "mm", 0.35, 0.0, 0.8, 0.0, 22.0, 160.0,
		(1211, "Framing gate clamp CL4 not closed", 1.25)),
	("ST30", "Topcoat Paint Booth", 2, 36.0, "Booth temperature", "degC", 23.0, 21.0, 25.0, 23.0, 85.0, 120.0,
		(1307, "Booth downdraft airflow low", 27.4)),
	("ST40", "Door Installation", 2, 30.0, "Door gap / flush", "mm", 3.5, 3.0, 4.0, 0.0, 9.0, 34.0,
		(1402, "Door hinge bolt runner NOK", 4.6)),
	("ST50", "Powertrain Marriage", 1, 37.0, "Mount bolt torque", "Nm", 120.0, 110.0, 130.0, 0.0, 12.0, 46.0,
		(1509, "AGV lift height deviation", 96.0)),
	("ST60", "Windshield Glazing", 1, 32.0, "Urethane bead temp", "degC", 60.0, 55.0, 65.0, 48.0, 8.0, 26.0,
		(1603, "Urethane bead vision check failed", 51.0)),
	("ST70", "Wheel & Tire Mounting", 2, 33.0, "Lug nut torque", "Nm", 140.0, 130.0, 150.0, 0.0, 10.0, 38.0,
		(1711, "Nutrunner spindle 3 torque low", 112.0)),
	("ST80", "Fluid Fill & EOL Test", 0, 35.0, "Coolant fill", "L", 7.2, 7.0, 7.4, 0.0, 14.0, 52.0,
		(1806, "Coolant evacuation leak test failed", 6.4)),
]
ST_BY_CODE = dict([(s[0], s) for s in STATIONS])
CODES = [s[0] for s in STATIONS]

TRANSFER_S = 6.0                      # skid transfer between stations (indexing line)
DEFAULT_TARGET_JPH = 75.0


def _log():
	return system.util.getLogger(LOGGER_NAME)


# ---------------------------------------------------------------- tag model

# valueChanged event script on every UDT member / line tag the pages show. Inlined (no project
# library call) so it works whatever the Gateway Scripting Project setting is. It signals this page
# (key "ST10") and the plant page QAS.Plant3D (key "CarLine/ST10"), where this line is Line 3.
EVENT_SCRIPT = (
	"\t# QAS CarLine3D + Plant3D: wake both 3D pages (WebDev long-polls). Keep this script.\n"
	"\tfrom java.lang import System\n"
	"\tG = system.util.getGlobals()\n"
	"\tp = str(tagPath).replace(\"\\\\\", \"/\").split(\"/\")\n"
	"\tfor rk, k in ((\"qas_carline3d_rt\", p[-2]), (\"qas_plant3d_rt\", p[-3].split(\"]\")[-1] + \"/\" + p[-2])):\n"
	"\t\trt = G.get(rk)\n"
	"\t\tif rt is None:\n"
	"\t\t\tcontinue  # that page has not connected since the gateway started\n"
	"\t\ts = rt.get(\"seq\").incrementAndGet()\n"
	"\t\trt.get(\"chg\").put(k, s)\n"
	"\t\trt.get(\"events\").incrementAndGet()\n"
	"\t\trt.get(\"lastEventMs\").set(System.currentTimeMillis())\n"
	"\t\tl = rt.get(\"lock\")\n"
	"\t\tl.lock()\n"
	"\t\ttry:\n"
	"\t\t\trt.get(\"cond\").signalAll()\n"
	"\t\tfinally:\n"
	"\t\t\tl.unlock()\n"
)


def _mem(name, dataType, value, engUnit=None, doc=None, event=True):
	t = {"name": name, "tagType": "AtomicTag", "valueSource": "memory", "dataType": dataType, "value": value}
	if engUnit:
		t["engUnit"] = engUnit
	if doc:
		t["documentation"] = doc
	if event:
		t["eventScripts"] = [{"eventid": "valueChanged", "script": EVENT_SCRIPT}]
	return t


def _expr(name, dataType, expression, doc=None):
	t = {"name": name, "tagType": "AtomicTag", "valueSource": "expr", "dataType": dataType, "expression": expression}
	if doc:
		t["documentation"] = doc
	return t


def udtDefinition():
	"""UDT CarStation: one per assembly station. PLC-ready: swap valueSource to opc and use {PlcPath}."""
	return {
		"name": UDT_NAME,
		"tagType": "UdtType",
		"documentation": "Car assembly station (QAS CarLine3D). States: 0 Stopped, 1 Running, 2 Idle, 3 Blocked, 4 Faulted, 5 Maintenance",
		"parameters": {
			"PlcPath": {"dataType": "String", "value": "ns=1;s=[PLC2]CarLine"},
			"StationName": {"dataType": "String", "value": ""},
			"PVName": {"dataType": "String", "value": "Process value"},
			"PVUnit": {"dataType": "String", "value": ""},
			"Robots": {"dataType": "Integer", "value": 0},
		},
		"tags": [
			_mem("State", "Int4", 0, doc="0 Stopped, 1 Running, 2 Idle (waiting/starved), 3 Blocked, 4 Faulted, 5 Maintenance"),
			_mem("Mode", "Int4", 0, doc="0 Auto, 1 Manual (cycle completes only on operator step)"),
			_mem("Progress", "Float4", 0.0, "%", "Cycle progress of the body in station"),
			_mem("CycleTime", "Float4", 0.0, "s", "Last / current cycle time"),
			_mem("IdealCycle", "Float4", 35.0, "s", "Design cycle time"),
			_mem("Count", "Int4", 0, doc="Bodies completed this shift"),
			_mem("Rejects", "Int4", 0, doc="Bodies flagged for repair this shift"),
			_mem("FaultCode", "Int4", 0),
			_mem("FaultText", "String", ""),
			_mem("VIN", "String", "", doc="VIN of the body currently in station"),
			_mem("PartPresent", "Boolean", False, doc="Skid / body present photo-eye"),
			_mem("RobotsActive", "Int4", 0, doc="Robots currently executing a program"),
			_mem("PV", "Float4", 0.0, doc="Key process value (see PVName / PVUnit)"),
			_mem("PVLow", "Float4", 0.0, doc="Process window low limit"),
			_mem("PVHigh", "Float4", 0.0, doc="Process window high limit"),
			_mem("EnergyKW", "Float4", 0.0, "kW", "Station power draw"),
			_expr("RobotCount", "Int4", "{Robots}"),
			# Descriptive text: memory tags set per instance. (A UDT parameter inside an expression
			# string literal, e.g. "\"{StationName}\"", is NOT substituted - it reads back literally.)
			_mem("StationName", "String", "", event=False),
			_mem("PVName", "String", "", event=False),
			_mem("PVUnit", "String", "", event=False),
		],
	}


def lineTags():
	return [
		_mem("Running", "Boolean", True, doc="Line run command / status"),
		_mem("SimEnabled", "Boolean", True, doc="Gateway simulator writes the CarLine tags while true. Set false with a real PLC.", event=False),
		_mem("SpeedPct", "Float4", 100.0, "%", "Conveyor / cycle speed override"),
		_mem("JPH", "Float4", 0.0, "jph", "Jobs (vehicles) per hour, actual"),
		_mem("TargetJPH", "Float4", DEFAULT_TARGET_JPH, "jph", "Planned rate"),
		_mem("OEE", "Float4", 0.0, "%"),
		_mem("Good", "Int4", 0, doc="Vehicles off line this shift"),
		_mem("ShiftTarget", "Int4", 0, doc="Planned vehicles by now this shift"),
		_mem("IndexCount", "Int4", 0, doc="Increments on every line transfer (index)"),
		_mem("Transfer", "Boolean", False, doc="True while skids are transferring"),
		_mem("TaktTime", "Float4", 0.0, "s", "Last measured index-to-index time"),
		_mem("Andon", "Int4", 0, doc="Stations currently calling andon (faulted)"),
	]


def instanceTags():
	out = []
	for (code, name, robots, ideal, pvName, pvUnit, nom, lo, hi, idlePv, idleKw, runKw, fault) in STATIONS:
		out.append({
			"name": code,
			"tagType": "UdtInstance",
			"typeId": UDT_NAME,
			"parameters": {
				"StationName": {"dataType": "String", "value": name},
				"PVName": {"dataType": "String", "value": pvName},
				"PVUnit": {"dataType": "String", "value": pvUnit},
				"Robots": {"dataType": "Integer", "value": robots},
			},
			"tags": [
				{"name": "IdealCycle", "tagType": "AtomicTag", "value": ideal},
				{"name": "PVLow", "tagType": "AtomicTag", "value": lo},
				{"name": "PVHigh", "tagType": "AtomicTag", "value": hi},
				{"name": "PV", "tagType": "AtomicTag", "value": idlePv},
			] + _textOverrides(name, pvName, pvUnit),
		})
	return out


def _textOverrides(name, pvName, pvUnit):
	return [{"name": "StationName", "tagType": "AtomicTag", "valueSource": "memory", "value": name},
		{"name": "PVName", "tagType": "AtomicTag", "valueSource": "memory", "value": pvName},
		{"name": "PVUnit", "tagType": "AtomicTag", "valueSource": "memory", "value": pvUnit}]


def migrateTextTags():
	"""Tags created by the first version had StationName / PVName / PVUnit as expression tags that
	read back '{StationName}'. Turn them into memory tags with the real text, keeping all live values."""
	qv = system.tag.readBlocking([BASE + "/ST10/StationName"])[0]
	if qv.quality.isGood() and "{" not in unicode(qv.value or "{"):
		return False
	system.tag.configure(PROVIDER + "_types_", [udtDefinition()], "m")
	inst = [{"name": s[0], "tagType": "UdtInstance", "typeId": UDT_NAME, "tags": _textOverrides(s[1], s[4], s[5])}
		for s in STATIONS]
	res = system.tag.configure(BASE, inst, "m")
	_log().info("CarLine3D text tags migrated: %s" % res)
	return True


def ensureTags(force=False):
	"""Create the UDT and [default]CarLine if missing. force=True overwrites them (keeps nothing)."""
	G = system.util.getGlobals()
	if not force and G.get(READY_KEY):
		return False
	have = system.tag.exists(UDT_PATH) and system.tag.exists(BASE + "/Line/Running") \
		and system.tag.exists(BASE + "/ST80/State")
	if have and not force:
		migrateTextTags()
		G[READY_KEY] = True
		return False
	policy = "o" if force else "m"
	res = system.tag.configure(PROVIDER + "_types_", [udtDefinition()], policy)
	_log().info("CarLine3D UDT configure: %s" % res)
	folder = {"name": "CarLine", "tagType": "Folder",
		"tags": [{"name": "Line", "tagType": "Folder", "tags": lineTags()}] + instanceTags()}
	res = system.tag.configure(PROVIDER, [folder], policy)
	_log().info("CarLine3D tags configure: %s" % res)
	G[READY_KEY] = True
	return True


def exportTagJson():
	"""Same definitions as JSON (for Tag Browser import into another gateway)."""
	return system.util.jsonEncode({"udt": udtDefinition(),
		"tags": {"name": "CarLine", "tagType": "Folder",
			"tags": [{"name": "Line", "tagType": "Folder", "tags": lineTags()}] + instanceTags()}}, 2)


# ---------------------------------------------------------------- shared runtime state

def runtime():
	G = system.util.getGlobals()
	rt = G.get(RT_KEY)
	if rt is not None:
		return rt
	from java.util.concurrent import ConcurrentHashMap
	from java.util.concurrent.atomic import AtomicLong
	from java.util.concurrent.locks import ReentrantLock
	from java.lang import System
	lock = ReentrantLock()
	fresh = ConcurrentHashMap()
	fresh.put("seq", AtomicLong(0))
	fresh.put("lock", lock)
	fresh.put("cond", lock.newCondition())
	fresh.put("chg", ConcurrentHashMap())
	fresh.put("epoch", AtomicLong(System.currentTimeMillis()))
	fresh.put("events", AtomicLong(0))
	fresh.put("lastEventMs", AtomicLong(0))
	fresh.put("simMs", AtomicLong(0))           # last simulator tick (CAS guard across viewers)
	fresh.put("simTicks", AtomicLong(0))
	return G.setdefault(RT_KEY, fresh)


def notifyChange(key, rt=None):
	rt = rt or runtime()
	s = rt.get("seq").incrementAndGet()
	rt.get("chg").put(key, s)
	lock = rt.get("lock")
	lock.lock()
	try:
		rt.get("cond").signalAll()
	finally:
		lock.unlock()
	return s


# ---------------------------------------------------------------- tags

def _val(qv):
	if not qv.quality.isGood():
		return None
	v = qv.value
	if isinstance(v, bool) or v is None:
		return v
	try:
		if isinstance(v, (int, long)):
			return int(v)
		return float(v)
	except (TypeError, ValueError):
		return unicode(v)


def readKeys(keys):
	paths, plan = [], []
	for k in keys:
		members = LINE_MEMBERS if k == LINE_KEY else ST_MEMBERS
		plan.append((k, members))
		paths += ["%s/%s/%s" % (BASE, k, m) for m in members]
	qvs = system.tag.readBlocking(paths) if paths else []
	line, stations, i = None, {}, 0
	for (k, members) in plan:
		d = {}
		for m in members:
			d[m] = _val(qvs[i])
			i += 1
		if k == LINE_KEY:
			line = d
		else:
			if d.get("State") is None:
				d["State"] = 0
			stations[k] = d
	return line, stations


# ---------------------------------------------------------------- auth

def authorize(session):
	if not ALLOWED_ROLES:
		return True, None
	from java.lang import Exception as _JavaEx
	try:
		u = session.get("user") if session is not None else None
		roles = [unicode(r).lower() for r in u.getRoles()] if u is not None else []
	except (Exception, _JavaEx):
		roles = []
	allowed = [r.lower() for r in ALLOWED_ROLES]
	for r in roles:
		if r in allowed:
			return True, None
	return False, "user lacks a CarLine3D role (enable Require Auth on CarLine3D/data)"


# ---------------------------------------------------------------- WebDev entry point

def _int(raw, default):
	try:
		return int(unicode(raw).strip())
	except Exception:
		return default


def _simPump(rt):
	"""Run one simulator tick if SimEnabled and none ran in the last SIM_TICK_MS (any viewer)."""
	from java.lang import System
	now = System.currentTimeMillis()
	a = rt.get("simMs")
	last = a.get()
	if now - last < SIM_TICK_MS or not a.compareAndSet(last, now):
		return
	try:
		if system.tag.readBlocking([BASE + "/Line/SimEnabled"])[0].value:
			simTick()
			rt.get("simTicks").incrementAndGet()
	except Exception as e:
		_log().warn("CarLine3D simTick failed: %s" % e)


def handleData(request, session):
	"""GET CarLine3D/data
	   ?since=<seq>  -1/absent = full snapshot; otherwise wait for a tag change after <seq>
	   ?wait=<ms>    max wait (default 20000, max 25000)
	   ?diag=1       runtime counters
	   ?setup=1      (re)create the UDT and tags if missing; ?setup=force overwrites them"""
	from java.lang import System
	from java.util.concurrent import TimeUnit
	resp = request["servletResponse"]
	resp.setHeader("Cache-Control", "no-store")

	ok, why = authorize(session)
	if not ok:
		resp.setStatus(403)
		return {"json": {"error": why}}

	params = request["params"] or {}
	setup = unicode(params.get("setup") or "")
	created = ensureTags(force=(setup == "force")) if setup else ensureTags()

	rt = runtime()
	seqA = rt.get("seq")
	epoch = rt.get("epoch").get()

	if unicode(params.get("diag") or "") == "1" or setup:
		chg = rt.get("chg")
		return {"json": {
			"seq": seqA.get(), "epoch": epoch, "tagEvents": rt.get("events").get(), "created": created,
			"simTicks": rt.get("simTicks").get(), "lastEventMs": rt.get("lastEventMs").get(),
			"now": System.currentTimeMillis(), "stations": CODES,
			"lastChangeSeq": dict([(unicode(k), chg.get(k)) for k in chg.keySet()]),
			"hint": "tagEvents should rise when a CarLine tag changes."}}

	since = _int(params.get("since"), -1)
	clientEpoch = _int(params.get("epoch"), 0)
	wait = max(0, min(_int(params.get("wait"), WAIT_DEFAULT_MS), WAIT_MAX_MS))
	t0 = System.currentTimeMillis()

	_simPump(rt)
	full = since < 0 or since > seqA.get() or (clientEpoch and clientEpoch != epoch)

	if not full and seqA.get() == since and wait > 0:
		lock, cond = rt.get("lock"), rt.get("cond")
		deadline = t0 + wait
		while seqA.get() == since:
			remaining = deadline - System.currentTimeMillis()
			if remaining <= 0:
				break
			lock.lock()
			try:
				if seqA.get() == since:
					cond.awaitNanos(TimeUnit.MILLISECONDS.toNanos(min(remaining, SIM_TICK_MS)))
			finally:
				lock.unlock()
			if seqA.get() == since:
				_simPump(rt)          # writes tags -> tag events -> wakes this loop
		if seqA.get() != since and SETTLE_MS > 0:
			from java.lang import Thread
			Thread.sleep(SETTLE_MS)

	cur = seqA.get()
	if full:
		keys = [LINE_KEY] + CODES
	else:
		chg = rt.get("chg")
		keys = [k for k in [LINE_KEY] + CODES if (chg.get(k) or 0) > since]
	line, stations = readKeys(keys)
	out = {"seq": cur, "epoch": epoch, "full": bool(full), "changed": keys, "stations": stations,
		"ts": System.currentTimeMillis(), "waitedMs": System.currentTimeMillis() - t0}
	if line is not None:
		out["line"] = line
	return {"json": out}


# ---------------------------------------------------------------- WebDev command API (doPost)

def _body(request):
	pd = request.get("postData")
	if isinstance(pd, (str, unicode)):
		pd = system.util.jsonDecode(pd) if pd.strip() else {}
	if pd is None:
		pd = {}
	try:
		return dict(pd)
	except Exception:
		return {}


def _who(request, session):
	from java.lang import Exception as _JavaEx
	try:
		u = session.get("user") if session is not None else None
		name = unicode(u.get("username")) if u is not None else "anonymous"
	except (Exception, _JavaEx):
		name = "anonymous"
	try:
		addr = unicode(request["servletRequest"].getRemoteAddr())
	except (Exception, _JavaEx):
		addr = "?"
	return "%s@%s" % (name, addr)


def _bool(v):
	if isinstance(v, (str, unicode)):
		return v.strip().lower() in ("1", "true", "yes", "on")
	return bool(v)


def handleCommand(request, session):
	"""POST CarLine3D/data   header X-CarLine3D: 1   JSON body {cmd, ...}
	     {"cmd":"line","running":true}            Line/Running
	     {"cmd":"sim","enabled":false}             Line/SimEnabled
	     {"cmd":"speed","pct":110}                 Line/SpeedPct   (50..150)
	     {"cmd":"targetJph","value":75}            Line/TargetJPH  (20..120)
	     {"cmd":"state","code":"ST30","state":4}   station State (+ fault code/text for 4)
	     {"cmd":"resetShift"}                      zero Good / Count / Rejects
	     {"cmd":"rescan"}                          gateway re-reads project files from disk
	   The page sees the result through the normal tag-event long-poll, not from this response."""
	resp = request["servletResponse"]
	resp.setHeader("Cache-Control", "no-store")
	ok, why = authorize(session)
	if not ok:
		resp.setStatus(403)
		return {"json": {"ok": False, "error": why}}
	# Custom header = a cross-site form or image cannot send this request (it would need a CORS
	# preflight, which this resource does not answer).
	if unicode(request["servletRequest"].getHeader("X-CarLine3D") or "") != "1":
		resp.setStatus(400)
		return {"json": {"ok": False, "error": "missing X-CarLine3D header"}}
	ensureTags()
	b = _body(request)
	cmd = unicode(b.get("cmd") or "")
	L = BASE + "/Line/"
	try:
		if cmd == "line":
			system.tag.writeBlocking([L + "Running"], [_bool(b.get("running"))])
		elif cmd == "sim":
			system.tag.writeBlocking([L + "SimEnabled"], [_bool(b.get("enabled"))])
			notifyChange(LINE_KEY)        # SimEnabled has no tag event script; wake the page ourselves
		elif cmd == "speed":
			system.tag.writeBlocking([L + "SpeedPct"], [float(max(50, min(150, float(b.get("pct")))))])
		elif cmd == "targetJph":
			system.tag.writeBlocking([L + "TargetJPH"], [float(max(20, min(120, float(b.get("value")))))])
		elif cmd == "state":
			code, state = unicode(b.get("code") or ""), int(b.get("state"))
			if code not in CODES or state not in STATE_NAMES:
				raise ValueError("bad station or state")
			setStationState(code, state)
		elif cmd == "resetShift":
			resetShift()
		elif cmd == "rescan":
			# Re-read project files from disk (gateway scope). Used after editing resources outside the Designer.
			system.project.requestScan()
		else:
			raise ValueError("unknown cmd '%s'" % cmd)
	except (ValueError, TypeError) as e:
		resp.setStatus(400)
		return {"json": {"ok": False, "error": unicode(e)}}
	_log().info("CarLine3D command %s by %s" % (system.util.jsonEncode(b), _who(request, session)))
	return {"json": {"ok": True, "cmd": cmd}}


# ---------------------------------------------------------------- simulator / operator actions
# One line engine for the whole plant lives in QAS.Plant3D (this line is Line 3 there). It keeps the
# same behaviour as before and adds Auto/Manual mode and operator-held states.

def _line():
	return QAS.Plant3D.lineByKey("CarLine")


def setStationState(code, state):
	"""Operator write. Anything but Run (1) is held until Run / reset; a fault set here never self-clears."""
	return QAS.Plant3D.setStationState(_line(), code, state)


def injectFault(code):
	return setStationState(code, 4)


def resetFault(code):
	return setStationState(code, 1)


def resetShift():
	return QAS.Plant3D.resetShift(_line())


def simTick():
	"""One PLC scan of this line (about once a second). Also callable from a Gateway Timer Script."""
	ensureTags()
	return QAS.Plant3D.simLine(_line())
