# QAS.Line3D
# Event-driven data API for the Battery Cell Line 3D page.
#
# Same pattern as BRF.FormsReportingWeb:
#   * The page and its assets are WebDev TEXT resources under Line3D/ (index.html, model.gltf,
#     three.js modules). They call the Python resource Line3D/data with a RELATIVE url, so the
#     same files work unchanged in any project.
#   * Line3D/data/doGet is one line that delegates to handleData() below.
#
# What is different: the page does not poll on a timer. It holds a LONG-POLL request open and
# the gateway answers the moment a tag changes:
#
#   PLC / memory tag changes
#      -> valueChanged tag event script on the UDT member (and on Line/* tags)
#         bumps a sequence number and signals a Java Condition held in system.util.getGlobals()
#      -> every waiting  GET Line3D/data?since=<seq>  wakes up (no sleep loop, no timer)
#      -> reads ONLY the stations whose tags changed since <seq> and returns them
#      -> the page applies the delta and immediately asks again with the new seq
#
# Only Java objects are stored in getGlobals() (AtomicLong, ReentrantLock, Condition,
# ConcurrentHashMap), so the shared state survives project saves and script restarts without
# leaking old Jython classes.

BASE = "[default]BatteryLine"
LINE_KEY = "Line"
LINE_MEMBERS = ["Running", "SpeedPct", "OEE", "Rate", "Good"]
ST_MEMBERS = ["State", "CycleTime", "IdealCycle", "Count", "FaultCode", "FaultText"]

LOGGER_NAME = "QAS.Line3D"
RT_KEY = "qas_line3d_rt"            # must match the tag event scripts in the UDT / Line tags
STATIONS_KEY = "qas_line3d_stations"

WAIT_DEFAULT_MS = 20000             # how long one request may wait for a change
WAIT_MAX_MS = 25000                 # keep below proxy / Jetty idle timeouts (30 s typical)
SETTLE_MS = 40                      # after the first event, let a burst of writes land
STATION_CACHE_MS = 60000

# Roles allowed to call the data API. Empty = anyone the WebDev resource lets through.
# (Line3D/data ships with Require Auth OFF for the lab; turn it on for a plant network.)
ALLOWED_ROLES = []

# Optional: server-side change detection for tags that have NO valueChanged event script
# (for example if you point the page at existing PLC tags you cannot edit). 0 = off.
# When > 0, one waiting request at a time re-reads the tags every SCAN_MS and signals a change
# itself. Events from tag scripts still arrive instantly either way.
SCAN_MS = 0


def _log():
	return system.util.getLogger(LOGGER_NAME)


# ---------------------------------------------------------------- shared runtime state

def runtime():
	"""The shared change-signal. Created on first use; the tag event scripts only use it
	once it exists, so nothing is signalled before a page has connected."""
	G = system.util.getGlobals()
	rt = G.get(RT_KEY)
	if rt is not None:
		return rt
	from java.util.concurrent import ConcurrentHashMap
	from java.util.concurrent.atomic import AtomicLong
	from java.util.concurrent.locks import ReentrantLock
	from java.lang import System
	lock = ReentrantLock()
	fresh = ConcurrentHashMap()
	fresh.put("seq", AtomicLong(0))
	fresh.put("lock", lock)
	fresh.put("cond", lock.newCondition())
	fresh.put("chg", ConcurrentHashMap())          # key (ST10 / Line) -> seq of its last change
	fresh.put("epoch", AtomicLong(System.currentTimeMillis()))
	fresh.put("events", AtomicLong(0))             # changes signalled by tag scripts
	fresh.put("lastEventMs", AtomicLong(0))
	fresh.put("scanMs", AtomicLong(0))
	fresh.put("last", ConcurrentHashMap())         # used by the optional scanner only
	rt = G.setdefault(RT_KEY, fresh)
	return rt


def notifyChange(key, rt=None, fromTag=True):
	"""Mark station <key> (or 'Line') changed and wake every waiting request.
	The tag event scripts inline the same few lines so they do not depend on the
	Gateway Scripting Project setting."""
	from java.lang import System
	rt = rt or runtime()
	s = rt.get("seq").incrementAndGet()
	rt.get("chg").put(key, s)
	if fromTag:
		rt.get("events").incrementAndGet()
		rt.get("lastEventMs").set(System.currentTimeMillis())
	lock = rt.get("lock")
	lock.lock()
	try:
		rt.get("cond").signalAll()
	finally:
		lock.unlock()
	return s


def keyFromTagPath(tagPath):
	"""'[default]BatteryLine/ST10/State' -> 'ST10'; '[default]BatteryLine/Line/OEE' -> 'Line'."""
	parts = unicode(tagPath).replace("\\", "/").split("/")
	return parts[-2] if len(parts) >= 2 else LINE_KEY


# ---------------------------------------------------------------- tags

def stationCodes():
	G = system.util.getGlobals()
	from java.lang import System
	now = System.currentTimeMillis()
	cache = G.get(STATIONS_KEY)
	if cache is None or now - cache[0] > STATION_CACHE_MS:
		res = system.tag.browse(BASE, {"tagType": "UdtInstance"}).getResults()
		codes = sorted([str(r["name"]) for r in res])
		cache = [now, codes]           # list of Java-safe primitives only
		G[STATIONS_KEY] = cache
	return list(cache[1])


def _val(qv):
	if not qv.quality.isGood():
		return None
	v = qv.value
	if isinstance(v, bool) or v is None:
		return v
	try:
		if isinstance(v, (int, long)):
			return int(v)
		return float(v)
	except (TypeError, ValueError):
		return unicode(v)


def readKeys(keys):
	"""One readBlocking for the given keys. Returns (line or None, {code: {...}})."""
	paths, plan = [], []
	for k in keys:
		members = LINE_MEMBERS if k == LINE_KEY else ST_MEMBERS
		plan.append((k, members))
		paths += ["%s/%s/%s" % (BASE, k, m) for m in members]
	qvs = system.tag.readBlocking(paths) if paths else []
	line, stations, i = None, {}, 0
	for (k, members) in plan:
		d = {}
		for m in members:
			d[m] = _val(qvs[i])
			i += 1
		if k == LINE_KEY:
			line = d
		else:
			if d.get("State") is None:
				d["State"] = 0         # bad quality: show the station as Stopped
			stations[k] = d
	return line, stations


# ---------------------------------------------------------------- optional scanner

def _scanOnce(rt, codes):
	"""Re-read everything and signal keys whose values differ from the last scan."""
	from java.lang import System
	now = System.currentTimeMillis()
	last = rt.get("scanMs").get()
	if now - last < SCAN_MS or not rt.get("scanMs").compareAndSet(last, now):
		return
	line, st = readKeys([LINE_KEY] + codes)
	snap = {LINE_KEY: line}
	snap.update(st)
	prev = rt.get("last")
	for k, d in snap.items():
		sig = unicode(sorted(d.items()))
		if prev.get(k) != sig:
			had = prev.get(k) is not None
			prev.put(k, sig)
			if had:
				notifyChange(k, rt, fromTag=False)


# ---------------------------------------------------------------- auth

def authorize(session):
	if not ALLOWED_ROLES:
		return True, None
	from java.lang import Exception as _JavaEx
	try:
		u = session.get("user") if session is not None else None
		roles = [unicode(r).lower() for r in u.getRoles()] if u is not None else []
	except (Exception, _JavaEx):
		roles = []
	allowed = [r.lower() for r in ALLOWED_ROLES]
	for r in roles:
		if r in allowed:
			return True, None
	return False, "user lacks a Line3D role (enable Require Auth on Line3D/data)"


# ---------------------------------------------------------------- WebDev entry point

def _int(raw, default):
	try:
		return int(unicode(raw).strip())
	except Exception:
		return default


def handleData(request, session):
	"""GET Line3D/data
	   ?since=<seq>   -1 or absent = full snapshot now; otherwise wait for a change after <seq>
	   ?wait=<ms>     max wait (default 20000, max 25000)
	   ?diag=1        runtime counters, no waiting (use it to check the tag scripts fire)
	Response: {seq, epoch, full, changed:[keys], line?, stations:{code:{...}}, ts, waitedMs}"""
	from java.lang import System
	from java.util.concurrent import TimeUnit
	resp = request["servletResponse"]
	resp.setHeader("Cache-Control", "no-store")

	ok, why = authorize(session)
	if not ok:
		resp.setStatus(403)
		return {"json": {"error": why}}

	params = request["params"] or {}
	rt = runtime()
	seqA = rt.get("seq")
	epoch = rt.get("epoch").get()

	if unicode(params.get("diag") or "") == "1":
		chg = rt.get("chg")
		return {"json": {
			"seq": seqA.get(), "epoch": epoch, "tagEvents": rt.get("events").get(),
			"lastEventMs": rt.get("lastEventMs").get(), "now": System.currentTimeMillis(),
			"stations": stationCodes(), "scanMs": SCAN_MS,
			"lastChangeSeq": dict([(unicode(k), chg.get(k)) for k in chg.keySet()]),
			"hint": "tagEvents should rise when a BatteryLine tag changes. If it stays 0, the "
				"valueChanged scripts are missing from the UDT / Line tags (re-import the tag JSON)."}}

	since = _int(params.get("since"), -1)
	clientEpoch = _int(params.get("epoch"), 0)
	wait = max(0, min(_int(params.get("wait"), WAIT_DEFAULT_MS), WAIT_MAX_MS))
	codes = stationCodes()
	t0 = System.currentTimeMillis()

	# A client from before a gateway restart, or one that is ahead of us: start over.
	full = since < 0 or since > seqA.get() or (clientEpoch and clientEpoch != epoch)

	if not full and seqA.get() == since and wait > 0:
		lock, cond = rt.get("lock"), rt.get("cond")
		deadline = t0 + wait
		slice_ms = SCAN_MS if SCAN_MS > 0 else wait
		while seqA.get() == since:
			remaining = deadline - System.currentTimeMillis()
			if remaining <= 0:
				break
			lock.lock()
			try:
				if seqA.get() == since:
					cond.awaitNanos(TimeUnit.MILLISECONDS.toNanos(min(remaining, slice_ms)))
			finally:
				lock.unlock()
			if SCAN_MS > 0 and seqA.get() == since:
				_scanOnce(rt, codes)
		if seqA.get() != since and SETTLE_MS > 0:
			from java.lang import Thread
			Thread.sleep(SETTLE_MS)       # coalesce a burst (e.g. 50 tags in one writeBlocking)

	cur = seqA.get()                      # take seq BEFORE reading: later changes are re-sent
	if full:
		keys = [LINE_KEY] + codes
	else:
		chg = rt.get("chg")
		keys = [k for k in [LINE_KEY] + codes if (chg.get(k) or 0) > since]
	line, stations = readKeys(keys)

	out = {"seq": cur, "epoch": epoch, "full": bool(full), "changed": keys,
		"stations": stations, "ts": System.currentTimeMillis(),
		"waitedMs": System.currentTimeMillis() - t0}
	if line is not None:
		out["line"] = line
	return {"json": out}


# ---------------------------------------------------------------- operator / demo actions

STATE_NAMES = {0: "Stopped", 1: "Running", 2: "Starved", 3: "Blocked", 4: "Faulted", 5: "Maintenance"}
FAULTS = {
	"ST10": (101, "Separator web break"), "ST20": (214, "Weld energy out of window"),
	"ST30": (305, "Case not seated"), "ST40": (412, "Fill weight low"),
	"ST50": (508, "Seal laser interlock open"), "ST60": (611, "Formation channel overtemp"),
	"ST70": (733, "IR above limit"), "ST80": (802, "Tray stacker jam"),
}


def setStationState(code, state):
	"""Write one station's State (and a matching fault) - used by the Perspective test panel.
	The 3D page reacts through the tag event, exactly as it would to a PLC change."""
	state = int(state)
	fc, ft = FAULTS.get(code, (999, "Fault")) if state == 4 else (0, "")
	p = "%s/%s/" % (BASE, code)
	return system.tag.writeBlocking([p + "State", p + "FaultCode", p + "FaultText"], [state, fc, ft])


def simTick():
	"""No-PLC demo: call from a Gateway Timer Script (fixed delay 1000 ms):
	       if system.tag.readBlocking(['[default]BatteryLine/Line/SimEnabled'])[0].value: QAS.Line3D.simTick()
	Every write it makes fires the tag events, so the page moves through the same path as real data."""
	import random
	from java.lang import System
	codes = stationCodes()
	G = system.util.getGlobals()
	oee = G.get("qas_line3d_sim_oee") or 85.0
	untilMap = G.get("qas_line3d_sim_until")
	if untilMap is None:
		from java.util.concurrent import ConcurrentHashMap
		untilMap = G.setdefault("qas_line3d_sim_until", ConcurrentHashMap())

	members = ["State", "IdealCycle", "Count", "FaultCode"]
	paths = ["%s/%s/%s" % (BASE, c, m) for c in codes for m in members]
	vals = [qv.value for qv in system.tag.readBlocking(paths)]
	cur = {}
	for i, c in enumerate(codes):
		s, ic, cnt, fc = vals[i * 4:(i + 1) * 4]
		cur[c] = {"State": s or 0, "IdealCycle": ic or 10.0, "Count": cnt or 0, "FaultCode": fc or 0}
	now = System.currentTimeMillis()

	for c in codes:
		st = cur[c]
		if st["State"] == 4 and now > (untilMap.get(c) or 0):
			st["State"], st["FaultCode"] = 1, 0
		elif st["State"] != 4 and random.random() < 0.003:
			st["State"], st["FaultCode"] = 4, FAULTS.get(c, (999, ""))[0]
			untilMap.put(c, now + random.randint(10000, 25000))

	fi = next((i for i, c in enumerate(codes) if cur[c]["State"] == 4), -1)
	for i, c in enumerate(codes):
		st = cur[c]
		if st["State"] == 4:
			continue
		st["State"] = 1 if fi < 0 else (2 if i > fi else (3 if i == fi - 1 else 1))
		if st["State"] == 1 and random.random() < 0.18:
			st["Count"] += 1

	wp, wv = [], []
	for c in codes:
		st = cur[c]
		ct = round(st["IdealCycle"] * (1 + random.random() * 0.12), 2)
		for m, v in (("State", st["State"]), ("CycleTime", ct), ("Count", st["Count"]),
				("FaultCode", st["FaultCode"]),
				("FaultText", FAULTS.get(c, (0, ""))[1] if st["FaultCode"] else "")):
			wp.append("%s/%s/%s" % (BASE, c, m))
			wv.append(v)

	oee += ((72.0 if fi >= 0 else 86.0) - oee) * 0.05
	G["qas_line3d_sim_oee"] = oee
	rate = 0.0 if fi >= 0 else round(60.0 / 14.0 * 2.1 + random.random() * 0.3, 2)
	last = codes[-1] if codes else None
	for m, v in (("Running", True), ("SpeedPct", 100.0), ("OEE", round(oee, 1)),
			("Rate", rate), ("Good", cur[last]["Count"] if last else 0)):
		wp.append("%s/Line/%s" % (BASE, m))
		wv.append(v)
	system.tag.writeBlocking(wp, wv)
