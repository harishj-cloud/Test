# QAS.Plant3D
# Data API, tag model and line simulator for the multi-line 3D plant (WebDev Plant3D/index.html).
#
#   Plant (Level 1)  ->  5 production lines (Level 2)  ->  stations (Level 3)
#
#   Line 1  Body Shop          [default]Plant/L1   UDT PlantStation   (new)
#   Line 2  Paint Shop         [default]Plant/L2   UDT PlantStation   (new)
#   Line 3  Final Assembly     [default]CarLine    UDT CarStation     (the existing car line, reused as is)
#   Line 4  Engine Assembly    [default]Plant/L4   UDT PlantStation   (new)
#   Line 5  Quality Inspection [default]Plant/L5   UDT PlantStation   (new)
#
#   Every line folder has  Line/*  memory tags (Running, SpeedPct, JPH, OEE, Good, Transfer ...)
#   plus EXPRESSION tags computed by Ignition from the station State/Mode tags:
#       Line/Faults, MaintCount, RunCount, BlockedCount, ManualCount, Status
#   and the plant roll-up is computed the same way from the five Line/Status tags:
#       [default]Plant/Summary/Status, LinesRunning, LinesFaulted, LinesMaint, TotalFaults, TotalGood, AvgOEE
#   So line and plant status are real tag values, not something the page invents.
#
#   Change detection is the same as QAS.CarLine3D: a valueChanged tag event script on every member
#   bumps a sequence number in system.util.getGlobals() and signals a Java Condition; a waiting
#   GET Plant3D/data?since=<seq> returns only the stations / lines whose tags changed.
#   The CarLine (Line 3) tags signal BOTH the old CarLine3D page and this one, so both pages keep working.
#
#   Simulator: simLine() is the one line-PLC stand-in for every line (QAS.CarLine3D.simTick delegates to
#   it). It writes only tags. Per station it honours Mode (0 Auto / 1 Manual: the cycle only completes on
#   an operator "step"), operator-held states (Stopped / Idle / Blocked / Maintenance set from the page
#   stay until Run / reset) and faults. Turn it off per line with Line/SimEnabled when a PLC drives the tags.

PROVIDER = "[default]"
PLANT = PROVIDER + "Plant"
UDT_NAME = "PlantStation"
UDT_PATH = PROVIDER + "_types_/" + UDT_NAME

LOGGER_NAME = "QAS.Plant3D"
RT_KEY = "qas_plant3d_rt"            # must match PLANT_EVENT_SCRIPT and QAS.CarLine3D.EVENT_SCRIPT
READY_KEY = "qas_plant3d_ready_v1"
SUMMARY_KEY = "Plant/Summary"

WAIT_DEFAULT_MS = 20000
WAIT_MAX_MS = 25000
SETTLE_MS = 40
SIM_TICK_MS = 1000
ALLOWED_ROLES = []                    # empty = anyone the WebDev resource lets through

STATE_NAMES = {0: "Stopped", 1: "Running", 2: "Idle", 3: "Blocked", 4: "Faulted", 5: "Maintenance"}
MODE_NAMES = {0: "Auto", 1: "Manual"}

ST_MEMBERS = ["State", "Mode", "Progress", "CycleTime", "IdealCycle", "Count", "Rejects", "FaultCode", "FaultText",
	"VIN", "PartPresent", "RobotsActive", "RobotCount", "PV", "PVLow", "PVHigh", "PVName", "PVUnit", "EnergyKW", "StationName"]
LINE_MEMBERS = ["Running", "SimEnabled", "SpeedPct", "JPH", "TargetJPH", "OEE", "Good", "ShiftTarget", "IndexCount",
	"Transfer", "TaktTime", "Andon", "Status", "Faults", "MaintCount", "RunCount", "BlockedCount", "ManualCount"]
SUMMARY_MEMBERS = ["Status", "LinesRunning", "LinesFaulted", "LinesMaint", "TotalFaults", "TotalGood", "AvgOEE"]

# Station tuples, same layout as QAS.CarLine3D.STATIONS:
# code, name, robots, ideal cycle s, PV name, unit, nominal, low, high, idle PV, idle kW, run kW, (fault code, text, PV when faulted)
L1_STATIONS = [
	("ST10", "Side Frame Welding", 4, 40.0, "Weld current", "kA", 10.2, 9.2, 11.2, 0.0, 20.0, 150.0, (2104, "Side frame fixture clamp not closed", 8.8)),
	("ST20", "Underbody Respot", 4, 38.0, "Weld current", "kA", 9.4, 8.4, 10.4, 0.0, 18.0, 140.0, (2207, "Weld tip misalignment detected", 11.4)),
	("ST30", "Roof Laser Brazing", 2, 42.0, "Laser power", "kW", 4.0, 3.6, 4.4, 0.0, 12.0, 60.0, (2311, "Laser optics contaminated", 3.1)),
	("ST40", "Closures Hemming", 2, 36.0, "Hemming force", "kN", 2.2, 1.9, 2.5, 0.0, 8.0, 32.0, (2402, "Hem roller wear limit reached", 1.6)),
	("ST50", "BIW Metrology", 2, 34.0, "Gap deviation", "mm", 0.25, 0.0, 0.6, 0.0, 6.0, 14.0, (2509, "Body geometry out of tolerance", 0.92)),
]
L2_STATIONS = [
	("ST10", "Pretreatment & E-coat", 0, 44.0, "E-coat voltage", "V", 320.0, 300.0, 340.0, 0.0, 95.0, 260.0, (3103, "E-coat rectifier over-current", 355.0)),
	("ST20", "Sealer Application", 2, 38.0, "Sealer bead width", "mm", 4.0, 3.5, 4.5, 0.0, 8.0, 30.0, (3205, "Sealer nozzle clogged", 2.6)),
	("ST30", "Primer Booth", 2, 40.0, "Primer film thickness", "um", 30.0, 26.0, 34.0, 0.0, 60.0, 110.0, (3307, "Primer film too thin", 22.0)),
	("ST40", "Topcoat Booth", 2, 42.0, "Topcoat film thickness", "um", 45.0, 40.0, 50.0, 0.0, 70.0, 130.0, (3402, "Bell cup speed low", 36.0)),
	("ST50", "Curing Oven", 0, 46.0, "Oven temperature", "degC", 140.0, 135.0, 145.0, 140.0, 180.0, 240.0, (3508, "Oven zone 3 burner flame-out", 118.0)),
	("ST60", "Paint Inspection", 0, 34.0, "Defects per body", "n", 0.6, 0.0, 2.0, 0.0, 5.0, 10.0, (3611, "Defect rate above limit", 4.0)),
]
L4_STATIONS = [
	("ST10", "Block Loading", 1, 28.0, "Pallet position error", "mm", 0.05, -0.2, 0.2, 0.0, 6.0, 18.0, (4102, "Block not seated on pallet", 0.45)),
	("ST20", "Crankshaft Install", 1, 32.0, "Bearing cap press force", "kN", 18.0, 16.0, 20.0, 0.0, 10.0, 45.0, (4204, "Bearing cap press force high", 22.5)),
	("ST30", "Piston & Rod Insertion", 2, 34.0, "Ring compression", "mm", 0.12, 0.05, 0.2, 0.0, 8.0, 28.0, (4306, "Piston ring jammed at bore", 0.31)),
	("ST40", "Cylinder Head Torque", 1, 30.0, "Head bolt torque", "Nm", 90.0, 85.0, 95.0, 0.0, 8.0, 30.0, (4401, "Head bolt angle NOK", 78.0)),
	("ST50", "Engine Cold Test", 0, 36.0, "Oil pressure", "bar", 3.2, 2.8, 3.6, 0.0, 10.0, 55.0, (4509, "Oil pressure low at 600 rpm", 2.1)),
]
L5_STATIONS = [
	("ST10", "Wheel Alignment", 0, 38.0, "Toe angle", "deg", 0.10, 0.0, 0.2, 0.0, 6.0, 15.0, (5103, "Toe out of tolerance", 0.34)),
	("ST20", "Roll & Brake Test", 0, 40.0, "Brake force imbalance", "%", 4.0, 0.0, 8.0, 0.0, 12.0, 90.0, (5207, "Brake imbalance rear axle", 12.5)),
	("ST30", "Water Leak Test", 0, 42.0, "Spray pressure", "bar", 2.4, 2.1, 2.7, 0.0, 15.0, 45.0, (5304, "Spray pump pressure low", 1.6)),
	("ST40", "Final Audit Light Tunnel", 0, 36.0, "Light level", "lux", 2000.0, 1800.0, 2200.0, 600.0, 4.0, 12.0, (5402, "Tunnel lamp failure", 1400.0)),
	("ST50", "ADAS Calibration", 1, 34.0, "Camera aim error", "deg", 0.05, 0.0, 0.15, 0.0, 5.0, 14.0, (5509, "Radar target not detected", 0.4)),
]


def _line(key, base, name, stations, transferS, targetJph, idPrefix, simKey=None):
	return {"key": key, "base": base, "name": name, "stations": stations, "codes": [s[0] for s in stations],
		"byCode": dict([(s[0], s) for s in stations]), "transferS": transferS, "targetJph": targetJph,
		"idPrefix": idPrefix, "simKey": simKey or ("qas_plant3d_sim_" + key)}


# Order = Line 1..5 on the page. Line 3 is the existing car line and its tags.
LINES = [
	_line("L1", PLANT + "/L1", "Body Shop", L1_STATIONS, 5.0, 60.0, "1QA%sB4E2%sTB%06d"),
	_line("L2", PLANT + "/L2", "Paint Shop", L2_STATIONS, 6.0, 60.0, "1QA%sP4E2%sTB%06d"),
	_line("CarLine", QAS.CarLine3D.BASE, "Final Assembly", QAS.CarLine3D.STATIONS, QAS.CarLine3D.TRANSFER_S,
		QAS.CarLine3D.DEFAULT_TARGET_JPH, "1QA%sA4E2%sTB%06d", QAS.CarLine3D.SIM_KEY),
	_line("L4", PLANT + "/L4", "Engine Assembly", L4_STATIONS, 4.0, 90.0, "K20%sE%s-%06d"),
	_line("L5", PLANT + "/L5", "Quality Inspection", L5_STATIONS, 6.0, 60.0, "1QA%sQ4E2%sTB%06d"),
]
LINE_BY_KEY = dict([(L["key"], L) for L in LINES])
NEW_LINES = [L for L in LINES if L["key"] != "CarLine"]


def lineByKey(key):
	return LINE_BY_KEY[key]


def _log():
	return system.util.getLogger(LOGGER_NAME)


# ---------------------------------------------------------------- tag model

PLANT_EVENT_SCRIPT = (
	"\t# QAS Plant3D: wake the plant 3D page (WebDev Plant3D/data long-poll). Keep this script.\n"
	"\trt = system.util.getGlobals().get(\"qas_plant3d_rt\")\n"
	"\tif rt is None:\n"
	"\t\treturn  # no plant page has connected since the gateway started\n"
	"\tfrom java.lang import System\n"
	"\tp = str(tagPath).replace(\"\\\\\", \"/\").split(\"/\")\n"
	"\tk = p[-3].split(\"]\")[-1] + \"/\" + p[-2]\n"
	"\ts = rt.get(\"seq\").incrementAndGet()\n"
	"\trt.get(\"chg\").put(k, s)\n"
	"\trt.get(\"events\").incrementAndGet()\n"
	"\trt.get(\"lastEventMs\").set(System.currentTimeMillis())\n"
	"\tl = rt.get(\"lock\")\n"
	"\tl.lock()\n"
	"\ttry:\n"
	"\t\trt.get(\"cond\").signalAll()\n"
	"\tfinally:\n"
	"\t\tl.unlock()\n"
)


def _ev(script):
	return [{"eventid": "valueChanged", "script": script}]


def _mem(name, dataType, value, engUnit=None, doc=None, event=True):
	t = {"name": name, "tagType": "AtomicTag", "valueSource": "memory", "dataType": dataType, "value": value}
	if engUnit:
		t["engUnit"] = engUnit
	if doc:
		t["documentation"] = doc
	if event:
		t["eventScripts"] = _ev(PLANT_EVENT_SCRIPT)
	return t


def _expr(name, dataType, expression, doc=None):
	t = {"name": name, "tagType": "AtomicTag", "valueSource": "expr", "dataType": dataType,
		"expression": expression, "eventScripts": _ev(PLANT_EVENT_SCRIPT)}
	if doc:
		t["documentation"] = doc
	return t


def udtDefinition():
	"""UDT PlantStation (lines 1, 2, 4, 5). Same members as CarStation, PLC-ready via {PlcPath}."""
	return {
		"name": UDT_NAME,
		"tagType": "UdtType",
		"documentation": "Plant station (QAS Plant3D). State: 0 Stopped, 1 Running, 2 Idle, 3 Blocked, 4 Faulted, 5 Maintenance. Mode: 0 Auto, 1 Manual",
		"parameters": {
			"PlcPath": {"dataType": "String", "value": "ns=1;s=[PLC]Plant"},
			"Robots": {"dataType": "Integer", "value": 0},
		},
		"tags": [
			_mem("State", "Int4", 0, doc="0 Stopped, 1 Running, 2 Idle, 3 Blocked, 4 Faulted, 5 Maintenance"),
			_mem("Mode", "Int4", 0, doc="0 Auto, 1 Manual (cycle completes only on operator step)"),
			_mem("Progress", "Float4", 0.0, "%"),
			_mem("CycleTime", "Float4", 0.0, "s"),
			_mem("IdealCycle", "Float4", 35.0, "s"),
			_mem("Count", "Int4", 0, doc="Parts completed this shift"),
			_mem("Rejects", "Int4", 0, doc="Parts sent to repair this shift"),
			_mem("FaultCode", "Int4", 0),
			_mem("FaultText", "String", ""),
			_mem("VIN", "String", "", doc="Serial / VIN of the part in station"),
			_mem("PartPresent", "Boolean", False),
			_mem("RobotsActive", "Int4", 0),
			_mem("PV", "Float4", 0.0),
			_mem("PVLow", "Float4", 0.0),
			_mem("PVHigh", "Float4", 0.0),
			_mem("EnergyKW", "Float4", 0.0, "kW"),
			{"name": "RobotCount", "tagType": "AtomicTag", "valueSource": "expr", "dataType": "Int4", "expression": "{Robots}"},
			_mem("StationName", "String", "", event=False),
			_mem("PVName", "String", "", event=False),
			_mem("PVUnit", "String", "", event=False),
		],
	}


def _lineMemoryTags(L):
	return [
		_mem("Running", "Boolean", True, doc="Line run command / status"),
		_mem("SimEnabled", "Boolean", True, doc="Gateway simulator writes this line's tags while true", event=False),
		_mem("SpeedPct", "Float4", 100.0, "%"),
		_mem("JPH", "Float4", 0.0, "jph"),
		_mem("TargetJPH", "Float4", L["targetJph"], "jph"),
		_mem("OEE", "Float4", 0.0, "%"),
		_mem("Good", "Int4", 0),
		_mem("ShiftTarget", "Int4", 0),
		_mem("IndexCount", "Int4", 0),
		_mem("Transfer", "Boolean", False),
		_mem("TaktTime", "Float4", 0.0, "s"),
		_mem("Andon", "Int4", 0),
	]


def _lineExprTags(L):
	"""Line status computed by Ignition from the station tags of this line."""
	b = L["base"]
	def count(member, value):
		return " + ".join(["toInt({%s/%s/%s} = %d)" % (b, c, member, value) for c in L["codes"]])
	ln = b + "/Line/"
	status = ("if({%sFaults} > 0, 4, if({%sMaintCount} > 0, 5, if(!{%sRunning}, 0, "
		"if({%sRunCount} > 0, 1, if({%sBlockedCount} > 0, 3, 2)))))") % (ln, ln, ln, ln, ln)
	return [
		_expr("Faults", "Int4", count("State", 4), "Stations faulted"),
		_expr("MaintCount", "Int4", count("State", 5), "Stations in maintenance"),
		_expr("RunCount", "Int4", count("State", 1), "Stations running"),
		_expr("BlockedCount", "Int4", count("State", 3), "Stations blocked"),
		_expr("ManualCount", "Int4", count("Mode", 1), "Stations in manual mode"),
		_expr("Status", "Int4", status, "Line status from station states: 0 Stopped 1 Running 2 Idle 3 Blocked 4 Faulted 5 Maintenance"),
	]


def _summaryTags():
	st = ["{%s/Line/Status}" % L["base"] for L in LINES]
	n = len(LINES)
	running = " + ".join(["toInt(%s >= 1 && %s <= 3)" % (s, s) for s in st])
	S = PLANT + "/Summary/"
	return [
		_expr("LinesRunning", "Int4", running),
		_expr("LinesFaulted", "Int4", " + ".join(["toInt(%s = 4)" % s for s in st])),
		_expr("LinesMaint", "Int4", " + ".join(["toInt(%s = 5)" % s for s in st])),
		_expr("TotalFaults", "Int4", " + ".join(["{%s/Line/Faults}" % L["base"] for L in LINES])),
		_expr("TotalGood", "Int4", " + ".join(["{%s/Line/Good}" % L["base"] for L in LINES])),
		_expr("AvgOEE", "Float4", "(%s) / %d" % (" + ".join(["{%s/Line/OEE}" % L["base"] for L in LINES]), n)),
		_expr("Status", "Int4", ("if({%sTotalFaults} > 0, 4, if({%sLinesMaint} > 0, 5, if({%sLinesRunning} = 0, 0, "
			"if({%sLinesRunning} = %d, 1, 2))))") % (S, S, S, S, n),
			"Plant status from line status: 0 Stopped 1 All running 2 Partly running 4 Faulted 5 Maintenance"),
	]


def _instances(L):
	out = []
	for (code, name, robots, ideal, pvName, pvUnit, nom, lo, hi, idlePv, idleKw, runKw, fault) in L["stations"]:
		out.append({"name": code, "tagType": "UdtInstance", "typeId": UDT_NAME,
			"parameters": {"Robots": {"dataType": "Integer", "value": robots}},
			"tags": [
				{"name": "IdealCycle", "tagType": "AtomicTag", "value": ideal},
				{"name": "PVLow", "tagType": "AtomicTag", "value": lo},
				{"name": "PVHigh", "tagType": "AtomicTag", "value": hi},
				{"name": "PV", "tagType": "AtomicTag", "value": idlePv},
				{"name": "StationName", "tagType": "AtomicTag", "value": name},
				{"name": "PVName", "tagType": "AtomicTag", "value": pvName},
				{"name": "PVUnit", "tagType": "AtomicTag", "value": pvUnit},
			]})
	return out


def _upgradeCarLine():
	"""Line 3 = existing CarLine. Adds Mode to UDT CarStation, switches its event scripts to the dual
	(CarLine3D + Plant3D) version, and adds the line status expression tags. Live values are kept."""
	C = QAS.CarLine3D
	if not system.tag.exists(C.BASE + "/ST10/Mode"):
		res = system.tag.configure(PROVIDER + "_types_", [C.udtDefinition()], "m")
		_log().info("CarStation UDT upgraded (Mode, dual event script): %s" % res)
		# line tags: only swap the event script, never the values
		evTags = [{"name": t["name"], "tagType": "AtomicTag", "eventScripts": t["eventScripts"]}
			for t in C.lineTags() if t.get("eventScripts")]
		system.tag.configure(C.BASE + "/Line", evTags, "m")


def ensureTags(force=False):
	"""Create everything that is missing. Never overwrites an existing tag's value."""
	G = system.util.getGlobals()
	if not force and G.get(READY_KEY):
		return False
	QAS.CarLine3D.ensureTags()
	_upgradeCarLine()
	if force or not system.tag.exists(UDT_PATH):
		_log().info("PlantStation UDT: %s" % system.tag.configure(PROVIDER + "_types_", [udtDefinition()], "m"))
	for L in NEW_LINES:
		if force or not system.tag.exists(L["base"] + "/Line/Running"):
			folder = {"name": L["key"], "tagType": "Folder",
				"tags": [{"name": "Line", "tagType": "Folder", "tags": _lineMemoryTags(L)}] + _instances(L)}
			_log().info("%s tags: %s" % (L["key"], system.tag.configure(PLANT, [folder], "m")))
	for L in LINES:
		if force or not system.tag.exists(L["base"] + "/Line/Status"):
			system.tag.configure(L["base"] + "/Line", _lineExprTags(L), "m")
	if force or not system.tag.exists(PLANT + "/Summary/Status"):
		system.tag.configure(PLANT, [{"name": "Summary", "tagType": "Folder", "tags": _summaryTags()}], "m")
	G[READY_KEY] = True
	return True


# ---------------------------------------------------------------- shared runtime state

def runtime():
	G = system.util.getGlobals()
	rt = G.get(RT_KEY)
	if rt is not None:
		return rt
	from java.util.concurrent import ConcurrentHashMap
	from java.util.concurrent.atomic import AtomicLong
	from java.util.concurrent.locks import ReentrantLock
	from java.lang import System
	lock = ReentrantLock()
	fresh = ConcurrentHashMap()
	fresh.put("seq", AtomicLong(0))
	fresh.put("lock", lock)
	fresh.put("cond", lock.newCondition())
	fresh.put("chg", ConcurrentHashMap())          # "L1/ST10", "CarLine/Line", "Plant/Summary" -> seq
	fresh.put("epoch", AtomicLong(System.currentTimeMillis()))
	fresh.put("events", AtomicLong(0))
	fresh.put("lastEventMs", AtomicLong(0))
	fresh.put("simMs", AtomicLong(0))
	fresh.put("simTicks", AtomicLong(0))
	return G.setdefault(RT_KEY, fresh)


def notifyChange(key, rt=None):
	rt = rt or runtime()
	s = rt.get("seq").incrementAndGet()
	rt.get("chg").put(key, s)
	lock = rt.get("lock")
	lock.lock()
	try:
		rt.get("cond").signalAll()
	finally:
		lock.unlock()
	return s


def allKeys():
	keys = [SUMMARY_KEY]
	for L in LINES:
		keys.append(L["key"] + "/Line")
		keys += [L["key"] + "/" + c for c in L["codes"]]
	return keys


def _val(qv):
	if not qv.quality.isGood():
		return None
	v = qv.value
	if isinstance(v, bool) or v is None:
		return v
	try:
		if isinstance(v, (int, long)):
			return int(v)
		return float(v)
	except (TypeError, ValueError):
		return unicode(v)


def _pathFor(key):
	lk, sub = key.split("/", 1)
	if lk == "Plant":
		return PLANT + "/" + sub, SUMMARY_MEMBERS
	return LINE_BY_KEY[lk]["base"] + "/" + sub, (LINE_MEMBERS if sub == "Line" else ST_MEMBERS)


def readKeys(keys):
	"""One readBlocking for all requested keys -> (summary or None, {lineKey: {line?, stations}})."""
	paths, plan = [], []
	for k in keys:
		base, members = _pathFor(k)
		plan.append((k, members))
		paths += ["%s/%s" % (base, m) for m in members]
	qvs = system.tag.readBlocking(paths) if paths else []
	summary, lines, i = None, {}, 0
	for (k, members) in plan:
		d = {}
		for m in members:
			d[m] = _val(qvs[i])
			i += 1
		lk, sub = k.split("/", 1)
		if lk == "Plant":
			summary = d
			continue
		e = lines.setdefault(lk, {"stations": {}})
		if sub == "Line":
			e["line"] = d
		else:
			if d.get("State") is None:
				d["State"] = 0
			e["stations"][sub] = d
	return summary, lines


# ---------------------------------------------------------------- WebDev: GET Plant3D/data

def authorize(session):
	if not ALLOWED_ROLES:
		return True, None
	from java.lang import Exception as _JavaEx
	try:
		u = session.get("user") if session is not None else None
		roles = [unicode(r).lower() for r in u.getRoles()] if u is not None else []
	except (Exception, _JavaEx):
		roles = []
	for r in roles:
		if r in [a.lower() for a in ALLOWED_ROLES]:
			return True, None
	return False, "user lacks a Plant3D role (enable Require Auth on Plant3D/data)"


def _int(raw, default):
	try:
		return int(unicode(raw).strip())
	except Exception:
		return default


def _simPump(rt):
	"""At most one simulator scan per SIM_TICK_MS for all viewers; each line only if its SimEnabled."""
	from java.lang import System
	now = System.currentTimeMillis()
	a = rt.get("simMs")
	last = a.get()
	if now - last < SIM_TICK_MS or not a.compareAndSet(last, now):
		return
	qvs = system.tag.readBlocking([L["base"] + "/Line/SimEnabled" for L in LINES])
	for L, qv in zip(LINES, qvs):
		if qv.value:
			try:
				simLine(L)
			except Exception as e:
				_log().warn("simLine %s failed: %s" % (L["key"], e))
	rt.get("simTicks").incrementAndGet()


def handleData(request, session):
	"""GET Plant3D/data ?since=<seq>&epoch=<e>&wait=<ms> | ?diag=1 | ?setup=1
	Response: {seq, epoch, full, changed:[keys], plant?, lines:{L1:{line?, stations:{ST10:{...}}}}}"""
	from java.lang import System
	from java.util.concurrent import TimeUnit
	resp = request["servletResponse"]
	resp.setHeader("Cache-Control", "no-store")
	ok, why = authorize(session)
	if not ok:
		resp.setStatus(403)
		return {"json": {"error": why}}
	params = request["params"] or {}
	setup = unicode(params.get("setup") or "")
	created = ensureTags(force=(setup == "force")) if setup else ensureTags()
	rt = runtime()
	seqA = rt.get("seq")
	epoch = rt.get("epoch").get()
	if unicode(params.get("diag") or "") == "1" or setup:
		chg = rt.get("chg")
		return {"json": {"seq": seqA.get(), "epoch": epoch, "created": created, "tagEvents": rt.get("events").get(),
			"simTicks": rt.get("simTicks").get(), "lines": [L["key"] for L in LINES],
			"lastChangeSeq": dict([(unicode(k), chg.get(k)) for k in chg.keySet()])}}

	since = _int(params.get("since"), -1)
	clientEpoch = _int(params.get("epoch"), 0)
	wait = max(0, min(_int(params.get("wait"), WAIT_DEFAULT_MS), WAIT_MAX_MS))
	t0 = System.currentTimeMillis()
	_simPump(rt)
	full = since < 0 or since > seqA.get() or (clientEpoch and clientEpoch != epoch)
	if not full and seqA.get() == since and wait > 0:
		lock, cond = rt.get("lock"), rt.get("cond")
		deadline = t0 + wait
		while seqA.get() == since:
			remaining = deadline - System.currentTimeMillis()
			if remaining <= 0:
				break
			lock.lock()
			try:
				if seqA.get() == since:
					cond.awaitNanos(TimeUnit.MILLISECONDS.toNanos(min(remaining, SIM_TICK_MS)))
			finally:
				lock.unlock()
			if seqA.get() == since:
				_simPump(rt)
		if seqA.get() != since and SETTLE_MS > 0:
			from java.lang import Thread
			Thread.sleep(SETTLE_MS)
	cur = seqA.get()
	keys = allKeys()
	if not full:
		chg = rt.get("chg")
		keys = [k for k in keys if (chg.get(k) or 0) > since]
	summary, lines = readKeys(keys)
	out = {"seq": cur, "epoch": epoch, "full": bool(full), "changed": keys, "lines": lines,
		"ts": System.currentTimeMillis(), "waitedMs": System.currentTimeMillis() - t0}
	if summary is not None:
		out["plant"] = summary
	return {"json": out}


# ---------------------------------------------------------------- WebDev: POST Plant3D/data

def _body(request):
	pd = request.get("postData")
	if isinstance(pd, (str, unicode)):
		pd = system.util.jsonDecode(pd) if pd.strip() else {}
	try:
		return dict(pd or {})
	except Exception:
		return {}


def _who(request, session):
	from java.lang import Exception as _JavaEx
	try:
		u = session.get("user") if session is not None else None
		name = unicode(u.get("username")) if u is not None else "anonymous"
	except (Exception, _JavaEx):
		name = "anonymous"
	try:
		addr = unicode(request["servletRequest"].getRemoteAddr())
	except (Exception, _JavaEx):
		addr = "?"
	return "%s@%s" % (name, addr)


def _bool(v):
	if isinstance(v, (str, unicode)):
		return v.strip().lower() in ("1", "true", "yes", "on")
	return bool(v)


def handleCommand(request, session):
	"""POST Plant3D/data, header X-CarLine3D: 1, JSON {cmd, line, ...}. line = L1 | L2 | CarLine | L4 | L5
	     line {running}  sim {enabled}  speed {pct}  targetJph {value}  resetShift
	     state {code, state 0..5}  mode {code, mode 0|1}  step {code}   (manual cycle complete)
	     allLines {running}  (plant level)   rescan  (gateway re-reads project files)"""
	resp = request["servletResponse"]
	resp.setHeader("Cache-Control", "no-store")
	ok, why = authorize(session)
	if not ok:
		resp.setStatus(403)
		return {"json": {"ok": False, "error": why}}
	if unicode(request["servletRequest"].getHeader("X-CarLine3D") or "") != "1":
		resp.setStatus(400)
		return {"json": {"ok": False, "error": "missing X-CarLine3D header"}}
	ensureTags()
	b = _body(request)
	cmd = unicode(b.get("cmd") or "")
	try:
		if cmd == "allLines":
			system.tag.writeBlocking([L["base"] + "/Line/Running" for L in LINES], [_bool(b.get("running"))] * len(LINES))
		elif cmd == "rescan":
			system.project.requestScan()
		else:
			L = LINE_BY_KEY.get(unicode(b.get("line") or ""))
			if L is None:
				raise ValueError("unknown line")
			p = L["base"] + "/Line/"
			if cmd == "line":
				system.tag.writeBlocking([p + "Running"], [_bool(b.get("running"))])
			elif cmd == "sim":
				system.tag.writeBlocking([p + "SimEnabled"], [_bool(b.get("enabled"))])
				notifyChange(L["key"] + "/Line")          # SimEnabled has no event script
			elif cmd == "speed":
				system.tag.writeBlocking([p + "SpeedPct"], [float(max(50, min(150, float(b.get("pct")))))])
			elif cmd == "targetJph":
				system.tag.writeBlocking([p + "TargetJPH"], [float(max(20, min(150, float(b.get("value")))))])
			elif cmd == "resetShift":
				resetShift(L)
			elif cmd in ("state", "mode", "step"):
				code = unicode(b.get("code") or "")
				if code not in L["codes"]:
					raise ValueError("unknown station")
				if cmd == "state":
					state = int(b.get("state"))
					if state not in STATE_NAMES:
						raise ValueError("bad state")
					setStationState(L, code, state)
				elif cmd == "mode":
					mode = int(b.get("mode"))
					if mode not in MODE_NAMES:
						raise ValueError("bad mode")
					system.tag.writeBlocking(["%s/%s/Mode" % (L["base"], code)], [mode])
				else:
					_simMap(L).put(code + ".step", 1.0)     # picked up by the next simLine scan
			else:
				raise ValueError("unknown cmd '%s'" % cmd)
	except (ValueError, TypeError) as e:
		resp.setStatus(400)
		return {"json": {"ok": False, "error": unicode(e)}}
	_log().info("Plant3D command %s by %s" % (system.util.jsonEncode(b), _who(request, session)))
	return {"json": {"ok": True, "cmd": cmd}}


# ---------------------------------------------------------------- operator actions

def _simMap(L):
	G = system.util.getGlobals()
	m = G.get(L["simKey"])
	if m is None:
		from java.util.concurrent import ConcurrentHashMap
		m = G.setdefault(L["simKey"], ConcurrentHashMap())
	return m


def _f(m, k, d=0.0):
	v = m.get(k)
	return float(v) if v is not None else d


def setStationState(L, code, state):
	"""Operator state write. Anything but Run (1) is HELD: the simulator leaves it until Run / reset.
	A fault set here also never clears by itself."""
	state = int(state)
	f = L["byCode"].get(code)
	p = "%s/%s/" % (L["base"], code)
	sim = _simMap(L)
	sim.put(code + ".hold", 0.0 if state == 1 else 1.0)
	if state == 4:
		fc, ft, pv = f[12] if f else (9999, "Fault", 0.0)
		sim.put(code + ".faultUntil", -1.0)
		return system.tag.writeBlocking([p + "State", p + "FaultCode", p + "FaultText", p + "PV"], [4, fc, ft, pv])
	sim.put(code + ".faultUntil", 0.0)
	return system.tag.writeBlocking([p + "State", p + "FaultCode", p + "FaultText"], [state, 0, ""])


def resetShift(L):
	paths, vals = [L["base"] + "/Line/Good"], [0]
	for c in L["codes"]:
		paths += ["%s/%s/Count" % (L["base"], c), "%s/%s/Rejects" % (L["base"], c)]
		vals += [0, 0]
	return system.tag.writeBlocking(paths, vals)


# ---------------------------------------------------------------- simulator (line PLC stand-in)

def _newId(L, sim):
	import random
	serial = int(_f(sim, "serial", 410000.0)) + 1
	sim.put("serial", float(serial))
	model = "U" if random.random() < 0.35 else "S"
	return L["idPrefix"] % (model, random.choice("0123456789X"), serial)


def _shiftStartMs(nowMs):
	from java.util import Calendar
	c = Calendar.getInstance()
	c.setTimeInMillis(nowMs)
	h = c.get(Calendar.HOUR_OF_DAY)
	start = 6 if 6 <= h < 14 else (14 if 14 <= h < 22 else 22)
	if h < 6:
		c.add(Calendar.DAY_OF_MONTH, -1)
	c.set(Calendar.HOUR_OF_DAY, start)
	c.set(Calendar.MINUTE, 0)
	c.set(Calendar.SECOND, 0)
	c.set(Calendar.MILLISECOND, 0)
	return c.getTimeInMillis()


def _readLine(L):
	keys = [L["key"] + "/Line"] + [L["key"] + "/" + c for c in L["codes"]]
	summary, lines = readKeys(keys)
	e = lines.get(L["key"], {"stations": {}})
	return e.get("line") or {}, e["stations"]


def simLine(L):
	"""One PLC scan of an indexing line (about once a second). Writes changed tags only.
	Safe to call from several places: a second call within 900 ms is ignored."""
	import random
	from java.lang import System
	sim = _simMap(L)
	now = System.currentTimeMillis()
	prev = sim.get("lastTickMs")
	if prev is not None:
		if now - float(prev) < 900 or not sim.replace("lastTickMs", prev, float(now)):
			return 0
	else:
		sim.put("lastTickMs", float(now))
	dt = min(2.5, max(0.0, (now - float(prev)) / 1000.0)) if prev is not None else 1.0
	BASE, CODES, BY = L["base"], L["codes"], L["byCode"]

	line, st = _readLine(L)
	wp, wv = [], []

	def put(key, member, old, new):
		if isinstance(new, float):
			new = round(new, 3)
		if old != new:
			wp.append("%s/%s/%s" % (BASE, key, member))
			wv.append(new)

	running = bool(line.get("Running"))
	speed = max(0.1, min(2.0, (line.get("SpeedPct") or 100.0) / 100.0))
	wasRunning = _f(sim, "wasRunning", 0.0) > 0
	sim.put("wasRunning", 1.0 if running else 0.0)

	shift = float(_shiftStartMs(now))
	if _f(sim, "shift", 0.0) != shift:
		if _f(sim, "shift", 0.0):
			resetShift(L)
			line["Good"] = 0
			for c in CODES:
				st[c]["Count"], st[c]["Rejects"] = 0, 0
		sim.put("shift", shift)
		sim.put("shiftSimStart", float(now))

	if not st[CODES[0]].get("VIN"):
		for c in CODES:
			v = _newId(L, sim)
			put(c, "VIN", st[c].get("VIN"), v)
			st[c]["VIN"] = v

	transferUntil = _f(sim, "transferUntil", 0.0)
	inTransfer = running and now < transferUntil
	if running and transferUntil and not inTransfer:          # transfer done: parts move one pitch
		sim.put("transferUntil", 0.0)
		lastVin = st[CODES[-1]].get("VIN")
		for i in range(len(CODES) - 1, 0, -1):
			st[CODES[i]]["VIN"] = st[CODES[i - 1]].get("VIN")
		st[CODES[0]]["VIN"] = _newId(L, sim)
		if lastVin:
			line["Good"] = (line.get("Good") or 0) + 1
			wp.append(BASE + "/Line/Good")
			wv.append(line["Good"])
		for c in CODES:
			sim.put(c + ".prog", 0.0)
			sim.put(c + ".done", 0.0)
			ideal = st[c].get("IdealCycle") or BY[c][3]
			sim.put(c + ".target", ideal * (0.9 + random.random() * 0.16))
			wp.append("%s/%s/VIN" % (BASE, c))
			wv.append(st[c]["VIN"])

	faultIdx = -1
	results = {}
	for i, c in enumerate(CODES):
		s = st[c]
		f = BY[c]
		ideal, fault = f[3], f[12]
		state = s["State"]
		mode = s.get("Mode") or 0
		hold = _f(sim, c + ".hold", 0.0) > 0
		step = _f(sim, c + ".step", 0.0) > 0
		if step:
			sim.put(c + ".step", 0.0)
		prog = _f(sim, c + ".prog", 0.0)
		target = _f(sim, c + ".target", 0.0) or (s.get("IdealCycle") or ideal)
		done = _f(sim, c + ".done", 0.0) > 0
		pv = s.get("PV") or 0.0
		fc, ft = s.get("FaultCode") or 0, s.get("FaultText") or ""

		if hold and state == 1:          # someone else (PLC / Designer) released it
			hold = False
		if not hold:
			sim.put(c + ".hold", 0.0)
		if running and not wasRunning and state == 0 and not hold:
			state = 1
		if not running:
			if state not in (4, 5) and not hold:
				state = 0
		elif state == 4:
			until = _f(sim, c + ".faultUntil", 0.0)
			if until >= 0 and now > until:
				state, fc, ft, hold = 1, 0, "", False
				sim.put(c + ".hold", 0.0)
		waiting = False
		if running and not hold and state in (1, 2, 3) and not inTransfer and not done:
			if mode == 1 and not step:            # manual: the station waits for the operator
				waiting = True
				state = 2
			else:
				state = 1
				if step:
					prog = target
				else:
					prog += dt * speed
					if mode == 0 and random.random() < 0.0022 * dt:
						state, fc, ft, pv = 4, fault[0], fault[1], fault[2]
						sim.put(c + ".faultUntil", float(now + random.randint(15000, 35000)))
				if state == 1 and prog >= target:
					prog, done = target, True
					s["Count"] = (s.get("Count") or 0) + 1
					put(c, "Count", None, s["Count"])
					put(c, "CycleTime", s.get("CycleTime"), target)
					if random.random() < 0.012:
						s["Rejects"] = (s.get("Rejects") or 0) + 1
						put(c, "Rejects", None, s["Rejects"])
		if (hold or state in (0, 4, 5)) and faultIdx < 0:
			faultIdx = i
		sim.put(c + ".prog", prog)
		sim.put(c + ".done", 1.0 if done else 0.0)
		results[c] = [state, prog, target, done, pv, fc, ft, hold, waiting]

	allDone = all(results[c][3] for c in CODES)
	if running and not inTransfer and allDone and faultIdx < 0:
		last = _f(sim, "lastIndexMs", 0.0)
		sim.put("lastIndexMs", float(now))
		sim.put("transferUntil", float(now + L["transferS"] / speed * 1000))
		inTransfer = True
		line["IndexCount"] = (line.get("IndexCount") or 0) + 1
		wp.append(BASE + "/Line/IndexCount")
		wv.append(line["IndexCount"])
		if last:
			takt = (now - last) / 1000.0
			put("Line", "TaktTime", line.get("TaktTime"), takt)
			jph = _f(sim, "jph", 0.0)
			sim.put("jph", 3600.0 / takt if not jph else jph + (3600.0 / takt - jph) * 0.35)

	faulted = 0
	for i, c in enumerate(CODES):
		s = st[c]
		f = BY[c]
		robots, nom, lo, hi, idlePv, idleKw, runKw = f[2], f[6], f[7], f[8], f[9], f[10], f[11]
		state, prog, target, done, pv, fc, ft, hold, waiting = results[c]
		if state == 4:
			faulted += 1
		elif hold:
			pass                                          # operator state stays as written
		elif running and inTransfer and state not in (0, 5):
			state = 1
		elif done and state in (1, 2, 3):
			state = 3 if (faultIdx >= 0 and i < faultIdx) else 2
		working = running and state == 1 and not inTransfer and not done and not hold
		if state != 4:
			if working:
				pv = nom + (random.random() - 0.5) * (hi - lo) * 0.3
			else:
				pv += (idlePv - pv) * 0.5
		ra = robots if working else 0
		kw = (runKw if working else idleKw) * (0.95 + random.random() * 0.1) if running or state == 5 else idleKw * 0.3
		progress = 0.0 if inTransfer else min(100.0, prog / target * 100.0 if target else 0.0)
		if working:
			put(c, "CycleTime", s.get("CycleTime"), prog)
		put(c, "State", s["State"], state)
		put(c, "Progress", s.get("Progress"), round(progress, 1))
		put(c, "FaultCode", s.get("FaultCode"), fc)
		put(c, "FaultText", s.get("FaultText"), ft)
		put(c, "PV", s.get("PV"), round(pv, 2))
		put(c, "RobotsActive", s.get("RobotsActive"), ra)
		put(c, "EnergyKW", s.get("EnergyKW"), round(kw, 1))
		put(c, "PartPresent", s.get("PartPresent"), bool(s.get("VIN")) and not inTransfer)

	targetJph = line.get("TargetJPH") or L["targetJph"]
	jph = _f(sim, "jph", 0.0)
	if not running or faulted:
		jph *= 0.985 ** dt
		sim.put("jph", jph)
	avail = _f(sim, "avail", 0.92)
	avail += ((1.0 if running and not faulted else 0.0) - avail) * 0.004 * dt
	sim.put("avail", avail)
	perf = min(1.0, jph / targetJph) if targetJph else 0.0
	good = line.get("Good") or 0
	rej = sum([(st[c].get("Rejects") or 0) for c in CODES])
	quality = float(good) / (good + rej) if good + rej else 1.0
	oee = max(0.0, min(100.0, avail * max(perf, 0.0) * quality * 100.0))
	start = max(_f(sim, "shift", float(now)), _f(sim, "shiftSimStart", float(now)))
	put("Line", "Transfer", line.get("Transfer"), bool(inTransfer))
	put("Line", "JPH", line.get("JPH"), round(jph, 1))
	put("Line", "OEE", line.get("OEE"), round(oee, 1))
	put("Line", "Andon", line.get("Andon"), faulted)
	put("Line", "ShiftTarget", line.get("ShiftTarget"), int(targetJph * (now - start) / 3600000.0))
	if wp:
		system.tag.writeBlocking(wp, wv)
	return len(wp)
