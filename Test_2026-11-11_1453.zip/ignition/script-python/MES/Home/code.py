# Payloads for the MES Home view.
# Each function returns a list of Flex Repeater instances; the keys besides
# instanceStyle / instancePosition map 1:1 to the template's input params.

# (title, subtitle, icon path, target page)
PRODUCTION = [
	("Coils",        "Yard layout & coil inventory", "material/radio_button_checked", "/coil-yard"),
	("Blanking",     "Blanking line coils & carts",  "material/content_cut",          "/blanking"),
	("Tandem",       "Tandem press line",            "material/view_column",          "/press"),
	("Scrap",        "Record and review scrap",      "material/delete",               "/scrap"),
	("Manual Entry", "Manual production entries",    "material/edit",                 "/manual-entry"),
	("Print Labels", "Coil and part labels",         "material/print",                "/print-labels"),
]

ADMINISTRATION = [
	("Dashboards",     "KPIs and shift reports",     "material/dashboard", "/dashboards"),
	("Users",          "Operators and access roles", "material/people",    "/users"),
	("Schuler OPC",    "Press OPC connection",       "material/wifi",      "/schuler-opc"),
	("Recipes Config", "Die and recipe settings",    "material/tune",      "/configuration"),
	("SAP Count Log",  "SAP posting history",        "material/flash_on",  "/sap-count-log"),
]

# Module highlighted on the Home page
ACTIVE = "Coils"


def _instance(**params):
	params["instanceStyle"] = {"classes": ""}
	params["instancePosition"] = {}
	return params


def getBadges():
	"""Badge text per module title. Placeholder until SAP failures are queried."""
	return {"SAP Count Log": "3 failed"}


def getModules(section):
	"""Tile payload for the 'production' or 'administration' repeater."""
	rows = PRODUCTION if section == "production" else ADMINISTRATION
	badges = getBadges()
	return [
		_instance(title=title, subtitle=subtitle, icon=icon, target=target,
				  active=(title == ACTIVE), badge=badges.get(title, ""))
		for title, subtitle, icon, target in rows
	]


def getKpis():
	"""KPI card payload. Values are placeholders until bound to yard/shift data."""
	return [
		_instance(label="Yard fill",  value="73%", note="",            tone="default"),
		_instance(label="Expired HT", value="11",  note="",            tone="warn"),
		_instance(label="Shift",      value="A",   note=u"06:00\u201314:30", tone="default"),
	]
