# Payloads for the MES Configuration view (Tandem Recipes / Configure Recipe).
# Flex Repeater payloads: keys besides instanceStyle / instancePosition map
# 1:1 to the template's input params.


def _instance(**params):
	params["instanceStyle"] = {"classes": ""}
	params["instancePosition"] = {}
	return params


TABS = [
	# (label, icon, target)
	("Blanking Recipes",   "material/content_cut",  "/configuration/blanking-recipes"),
	("Downtime",           "material/schedule",     "/configuration/downtime"),
	("Tandem Recipes",     "material/view_column",  "/configuration"),
	("Tandem Quality",     "material/check",        "/configuration/tandem-quality"),
	("Production Targets", "material/gps_fixed",    "/configuration/production-targets"),
	("Scheduling",         "material/event",        "/configuration/scheduling"),
]

SUB_TABS = [
	("Configured Parts List", "material/format_list_bulleted", "/configuration/parts-list"),
	("Configure Recipe",      "material/tune",                 "/configuration"),
]


def getTabs(active):
	"""Configuration sections (NavTab template)."""
	return [_instance(label=l, icon=i, target=t, active=(l == active), count="") for l, i, t in TABS]


def getSubTabs(active):
	"""Tandem Recipes sub-pages (SegTab template)."""
	return [_instance(label=l, icon=i, target=t, active=(l == active)) for l, i, t in SUB_TABS]


STATUS_OPTIONS = [
	{"value": "enabled",  "label": "Enabled"},
	{"value": "disabled", "label": "Disabled"},
	{"value": "all",      "label": "All"},
]


def getStatusOptions():
	"""Options for the Status dropdown."""
	return STATUS_OPTIONS


# Placeholder rows matching the current recipe list; replace with a named query.
# (RecipeId, Description, Enabled, Multipart)
_RECIPES = [
	(1,  "AIR-PNL RR QTR INR LH/RH",               True, False),
	(2,  "AIR-PNL FRT DR INR LH/RH",               True, True),
	(3,  "AIR-METAL ROOF PURE",                    True, False),
	(4,  "AIR-RR QTR OTR LH/RH",                   True, False),
	(5,  "AIR-PNL BODY SIDE OUTER PURE LH",        True, False),
	(6,  "AIR-PNL RR DR INR LH/RH",                True, True),
	(7,  "AIR-PNL HOOD OTR",                       True, False),
	(8,  "AIR-PNL FRT DR OTR LH/RH",               True, True),
	(9,  "AIR-PNL RR DR OTR LH/RH",                True, False),
	(10, "AIR-PNL BODY SIDE OUTER LH (GLASS ROOF)", True, False),
	(11, "AIR-PNL HOOD INR",                       True, False),
	(12, "SEALING CVR RR / SEALING CVR FRT",       True, True),
	(13, "RR SEALING CVR (16M) / STIFFNESS PLATE", True, True),
	(14, "AIR-PNL BODY SIDE OUTER PURE RH",        True, False),
	(15, "AIR-PNL BODYSIDE OUTER RH (GLASS ROOF)", True, False),
	(22, "GRAVITY-PNL FRT DR INR LH/RH",           True, True),
	(23, "GRAVITY-PNL FRT DR OTR LH/RH",           True, False),
	(24, "GRAVITY-PNL RR DR INR LH/RH",            True, True),
	(25, "GRAVITY-PNL RR DR OTR LH/RH",            True, True),
	(26, "GRAVITY-RR DR RING INR LH/RH",           True, False),
	(27, "GRAVITY-PNL LFT GT INR",                 True, False),
	(28, "GRAVITY-LFTGT OTR LWR / LIFTGT OTR UPR", True, True),
	(29, "GRAVITY-RR DR RING OTR LH/RH",           True, True),
	(30, "GRAVITY-FRT DR RING OTR LH",             True, False),
	(31, "GRAVITY-FRT DR RING OTR RH",             True, False),
]


def getRecipes(status="enabled"):
	"""Table data filtered by the Status dropdown ('enabled', 'disabled' or 'all')."""
	rows = []
	for recipeId, desc, enabled, multipart in _RECIPES:
		if status == "enabled" and not enabled:
			continue
		if status == "disabled" and enabled:
			continue
		rows.append({"RecipeId": recipeId, "Description": desc, "Enabled": enabled, "Multipart": multipart, "Edit": ""})
	return rows
