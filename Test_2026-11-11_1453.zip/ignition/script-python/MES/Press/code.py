# Payloads for the MES Tandem Press view (Line 2).
# Flex Repeater payloads: keys besides instanceStyle / instancePosition map
# 1:1 to the template's input params.


def _instance(**params):
	params["instanceStyle"] = {"classes": ""}
	params["instancePosition"] = {}
	return params


TABS = [
	# (label, icon, target)
	("Recorded Jobs",  "material/history", "/press"),
	("Validated Jobs", "material/check",   "/press/validated"),
]


def getTabs(active):
	"""Sub-navigation tabs. 'active' is the label of the selected tab."""
	counts = {"Recorded Jobs": "{:,}".format(getRecordedJobCount())}
	return [
		_instance(label=label, icon=icon, target=target, active=(label == active), count=counts.get(label, ""))
		for label, icon, target in TABS
	]


def getRecordedJobCount():
	"""Placeholder until the jobs table is queried."""
	return 2179


# Placeholder rows matching the current Line 2 screen; replace with a named query.
_JOBS = [
	(2179, "GRAVITY-STIFFENER B-PILLAR LH/RH",       38, "10/26/2026 10:55:09", "10/26/2026 13:32:54", 198),
	(2178, "AIR-PNL HOOD INR",                       11, "10/26/2026 09:24:16", "10/26/2026 10:55:09",  84),
	(2177, "RR SEALING CVR (16M) / STIFFNESS PLATE", 13, "10/26/2026 07:39:59", "10/26/2026 09:24:16", 394),
	(2176, "AIR-PNL BODY SIDE OUTER PURE LH",         5, "10/26/2026 06:31:51", "10/26/2026 07:39:59",  73),
	(2175, "GRAVITY-PNL BODY SIDE OTR RH",           37, "10/22/2026 09:04:35", "10/26/2026 06:31:51",  23),
	(2174, "AIR-PNL BODY SIDE OUTER PURE LH",         5, "10/22/2026 07:20:55", "10/22/2026 09:04:35",  16),
	(2173, "GRAVITY-FENDER OTR LH/RH",               42, "10/21/2026 15:49:59", "10/22/2026 07:20:55", 182),
	(2172, "GRAVITY-HOOD INR / HOOD OTR",            41, "10/21/2026 13:21:58", "10/21/2026 15:49:59", 249),
	(2171, "GRAVITY-PNL FRT DR RING INR LH",         32, "10/21/2026 11:21:22", "10/21/2026 13:21:58", 122),
	(2170, "GRAVITY-LFTGT OTR LWR / LIFTGT OTR UPR", 28, "10/21/2026 07:28:25", "10/21/2026 11:21:22", 365),
	(2169, "AIR-PNL RR DR OTR LH/RH",                 9, "10/20/2026 15:48:25", "10/21/2026 07:28:25", 189),
	(2168, "GRAVITY-PNL LFT GT INR",                 27, "10/20/2026 14:22:21", "10/20/2026 15:48:25", 500),
]

JOB_FIELDS = ["JobId", "Description", "RecipeId", "Started", "Ended", "Strokes", "Validated", "DefectsCount"]


def getJobs():
	"""Table data: list of row objects keyed by JOB_FIELDS."""
	return [
		dict(zip(JOB_FIELDS, [jobId, desc, recipe, started, ended, strokes, False, 0]))
		for jobId, desc, recipe, started, ended, strokes in _JOBS
	]


def jobsToCsv(rows):
	"""CSV text for the Export button."""
	def cell(v):
		s = unicode(v)
		return '"%s"' % s.replace('"', '""') if (',' in s or '"' in s) else s
	lines = [",".join(JOB_FIELDS)]
	for row in rows:
		lines.append(",".join(cell(row.get(f, "")) for f in JOB_FIELDS))
	return "\n".join(lines)


def getCurrentJob():
	"""Stat cards for the running job. Placeholder values until bound to the press tags."""
	def line(text, side, mono=False):
		return {"text": text, "side": side, "mono": mono}
	return [
		_instance(label="Recipe Strokes",      icon="material/trending_up",     value="25", unit="strokes",   lines=[], tone="default"),
		_instance(label="Stroke Rate",         icon="material/gps_fixed",       value="9",  unit="spm",       lines=[], tone="default"),
		_instance(label="Recipe",              icon="material/list_alt",        value="26", unit="recipe id", lines=[], tone="default"),
		_instance(label="Part Description(s)", icon="material/format_list_bulleted", value="", unit="", tone="default",
				  lines=[line("RR DR RING INR LH", "LH"), line("RR DR RING INR RH", "RH")]),
		_instance(label="Part Number(s)",      icon="material/bar_chart",       value="", unit="", tone="default",
				  lines=[line("P21-B62530-15", "LH", True), line("P21-B62540-15", "RH", True)]),
		_instance(label="Part Count(s)",       icon="material/trending_up",     value="", unit="", tone="default",
				  lines=[line("25", "LH"), line("25", "RH")]),
		_instance(label="Defects",             icon="material/sentiment_dissatisfied", value="", unit="", tone="good",
				  lines=[line("0", "LH"), line("0", "RH")]),
	]
