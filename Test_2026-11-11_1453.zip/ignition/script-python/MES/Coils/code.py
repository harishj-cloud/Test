# Payloads for the MES Coil Management view.
# Flex Repeater payloads: keys besides instanceStyle / instancePosition map
# 1:1 to the template's input params.
#
# Coil statuses: good, expired (expired heat treatment), hold, scrap, empty.
# Everything below is placeholder data matching the current screen; replace the
# module-level data with named queries / tags.


def _instance(position=None, **params):
	params["instanceStyle"] = {"classes": ""}
	params["instancePosition"] = position or {}
	return params


STATUS_COLORS = {
	"good": "#4D8A3C",
	"expired": "#D97A12",
	"hold": "#C9A400",
	"scrap": "#D35D47",
	"empty": "#DDD0BB",
}

STATUS_NAMES = {
	"good": "Good",
	"expired": "Expired Heat Treatment",
	"hold": "Hold",
	"scrap": "Scrap",
	"empty": "Empty",
}

# ---- Yard ---------------------------------------------------------------------
COLUMNS = list("JIHGFEDCBA")
ROWS = 11

# None = no spot (aisle), "" = empty spot, "!" prefix = expired heat treatment
_YARD = [
	["!1640761601", "!BB20250227-95", "077413-03", None, None, "1641646402", "1640843801", "073309-05", "7X086", "075267-02"],
	["1642393302", "", "073308-03", None, None, "", "4302868210", "077424-01", "077936-02", "4302872480"],
	["066871-03", "077415-02", "073308-07", None, None, "7WY12", "1643169703", "", "073308-06", "07887-01"],
	["IXE601315000", "", "077413-01", None, None, None, None, None, None, None],
	["", "066867-63", "075265-02", "075266-03", "077415-01", "075267-04", "073309-02", "1643172401", "", "IXA607444000"],
	["", "077415-03", "075267-03", "077411-01", "073307-05", "073307-02", "073308-04", "", "", "078879-03"],
	["075266-02", "073307-01", "!1640324601", "077411-02", "", "077413-02", "077413-05", "!1639849202", "075265-03", "4302868220"],
	["077436-03", "!BB20241015-40", "066867-06", "073308-02", "!1637529502-1", "075266-01", "077424-03", "", "075266-04", "078876-01"],
	["075267-01", "7X087", "078879-01", "!1640429601", "!1637529502-2", "073307-03", "077936-01", "", "", "073308-01"],
	["077424-04", "7X085", "078876-02", "1640560001", "075265-04", "075265-01", "1635306004", "7XP04", "7TX77", "073308-05"],
	["", "", "", "", "", "", "", "43028767950", "!1640500402", "!1640307502"],
]


def _spot(loc):
	"""(coilId, status) for a location like 'B7'; status 'gap' when there is no spot."""
	col = COLUMNS.index(loc[0])
	value = _YARD[int(loc[1:]) - 1][col]
	if value is None:
		return "", "gap"
	if value == "":
		return "", "empty"
	if value.startswith("!"):
		return value[1:], "expired"
	return value, "good"


def getYardColumns():
	"""Column letters for the yard header row (YardAxis template)."""
	return [_instance(text=c) for c in COLUMNS]


def getYardRows(statusFilter="all", search="", selected=""):
	"""One YardRow instance per row; each carries its tiles for the inner repeater."""
	search = (search or "").strip().upper()
	rows = []
	for r in range(1, ROWS + 1):
		tiles = []
		for c in COLUMNS:
			loc = "%s%d" % (c, r)
			coilId, status = _spot(loc)
			match = (statusFilter in ("all", status)) and (not search or search in coilId.upper() or search == loc)
			tiles.append({
				"loc": loc, "coilId": coilId, "status": status, "selected": loc == selected,
				"dim": status != "gap" and not match,
				# label the aisle once, in its middle
				"text": "AISLE" if loc == "G2" else "",
			})
		rows.append(_instance(row=r, tiles=tiles))
	return rows


FILTERS = [
	("All", "all", ""),
	("Good", "good", STATUS_COLORS["good"]),
	("Expired HT", "expired", STATUS_COLORS["expired"]),
	("Hold", "hold", STATUS_COLORS["hold"]),
	("Scrap", "scrap", STATUS_COLORS["scrap"]),
	("Empty", "empty", STATUS_COLORS["empty"]),
]


def getFilterChips(active="all"):
	return [_instance(label=l, value=v, color=col, active=(v == active)) for l, v, col in FILTERS]


# ---- Racks and blanking zone ------------------------------------------------------
_RACKS = [("K%d" % i, "", "empty") for i in range(1, 9)]


def getRacks():
	"""K1-K8, four per row."""
	pos = {"basis": "calc((100% - 24px) / 4)", "grow": 0, "shrink": 0}
	return [_instance(pos, name=n, coilId=c, status=s) for n, c, s in _RACKS]


_BLANKING = [
	# (name, status, coilId, note)
	("Mandrel",    "empty", "",           "No coil loaded"),
	("Cart 1",     "good",  "1642385601", ""),
	("Wrong Coil", "wrong", "",           "No coil in wrong-coil spot"),
	("Cart 2",     "empty", "",           "No coil loaded"),
]


def getBlankingZone():
	"""Mandrel, Cart 1, Wrong Coil, Cart 2 in a 2 x 2 grid."""
	pos = {"basis": "calc(50% - 4px)", "grow": 0, "shrink": 0}
	tags = {"good": "Good", "empty": "Empty", "wrong": "Empty"}
	return [_instance(pos, name=n, status=s, coilId=c, note=note, tag=tags[s]) for n, s, c, note in _BLANKING]


# ---- Spot statistics --------------------------------------------------------------
_SPOT_COUNTS = [("good", 68), ("expired", 11), ("empty", 29), ("hold", 0), ("scrap", 0)]


def _total():
	return sum(n for _, n in _SPOT_COUNTS)


def getSpotLegend():
	"""Spot Percentage legend, two per row."""
	total = float(_total()) or 1.0
	short = {"expired": "Expired HT"}
	pos = {"basis": "calc(50% - 8px)", "grow": 0, "shrink": 0}
	return [_instance(pos, label=short.get(s, STATUS_NAMES[s]), color=STATUS_COLORS[s], value="%.1f%%" % (n * 100 / total))
			for s, n in _SPOT_COUNTS]


def getSpotCounts():
	"""Spot Count rows, in the order of the original table."""
	counts = dict(_SPOT_COUNTS)
	return [_instance(label=STATUS_NAMES[s], color=STATUS_COLORS[s], value=str(counts[s])) for s in ("empty", "expired", "good")]


def getSpotSummary():
	total = _total()
	good = dict(_SPOT_COUNTS)["good"]
	return {"total": total, "goodPct": "%.1f%%" % (good * 100.0 / (total or 1))}



def getSpotTotalText():
	"""Subtitle of the Spot Percentage card."""
	return "%d spots" % _total()

def getDonut():
	"""Series, labels and colours for the ApexCharts donut (zero counts left out)."""
	shown = [(s, n) for s, n in _SPOT_COUNTS if n]
	short = {"expired": "Expired HT"}
	return {
		"series": [n for _, n in shown],
		"labels": [short.get(s, STATUS_NAMES[s]) for s, _ in shown],
		"colors": [STATUS_COLORS[s] for s, _ in shown],
	}


# ---- Location detail panel ----------------------------------------------------------
_DETAILS = {
	"B7": {
		"Coil Id": "1027", "Yield Strength": "", "Heat Treat Date": "Jan 1, 2026", "Weight": "5,805", "Weight Unit": "KG",
		"SAP Date Payload": "Apr 29, 2026, 1:35:44 PM", "Coil Description": "COIL, ALUMINUM 5182 +1.2 +1295",
		"Part Number": "Z00-Z45000-00", "Mill Id": "075265-03", "HU Number": "US0404292026000751",
	},
}

# (field, width, mono)
_FIELDS = [
	("Coil Id", "half", True), ("Yield Strength", "half", False),
	("Heat Treat Date", "full", False),
	("Weight", "half", False), ("Weight Unit", "half", False),
	("SAP Date Payload", "full", False),
	("Coil Description", "full", False),
	("Part Number", "full", True),
	("Mill Id", "full", True),
	("HU Number", "full", True),
]


def getLocationDetail(loc):
	"""Everything the right-hand panel shows for one location."""
	loc = loc or "B7"
	coilId, status = _spot(loc)
	values = _DETAILS.get(loc, {"Mill Id": coilId})
	fields = []
	for name, width, mono in _FIELDS:
		basis = "calc(50% - 5px)" if width == "half" else "100%"
		fields.append(_instance({"basis": basis, "grow": 0, "shrink": 0},
								label=name, value=values.get(name, ""), mono=mono))
	return {
		"loc": loc,
		"title": "Location " + loc,
		"subtitle": u"Row %s \u00b7 Column %s" % (loc[1:], loc[0]),
		"coilId": coilId or "No coil",
		"status": status,
		"statusText": {"good": "Good", "expired": "Expired HT", "hold": "Hold", "scrap": "Scrap"}.get(status, "Empty"),
		"fields": fields,
	}
