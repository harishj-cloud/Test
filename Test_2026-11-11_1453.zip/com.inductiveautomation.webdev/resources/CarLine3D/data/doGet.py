def doGet(request, session):
	# Long-poll data API for CarLine3D/index.html. Logic lives in QAS.CarLine3D.
	return QAS.CarLine3D.handleData(request, session)
