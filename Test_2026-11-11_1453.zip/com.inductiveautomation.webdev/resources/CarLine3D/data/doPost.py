def doPost(request, session):
	# Line control commands from CarLine3D/index.html. Logic lives in QAS.CarLine3D.
	return QAS.CarLine3D.handleCommand(request, session)
