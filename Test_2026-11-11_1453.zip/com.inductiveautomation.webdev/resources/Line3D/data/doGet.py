def doGet(request, session):
	# Long-poll data API for Line3D/index.html. Logic lives in QAS.Line3D.
	return QAS.Line3D.handleData(request, session)