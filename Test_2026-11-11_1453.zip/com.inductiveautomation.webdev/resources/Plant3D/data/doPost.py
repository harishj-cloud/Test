def doPost(request, session):
	# Plant / line / station commands from Plant3D/index.html. Logic lives in QAS.Plant3D.
	return QAS.Plant3D.handleCommand(request, session)
