def doGet(request, session):
	# Long-poll data API for Plant3D/index.html. Logic lives in QAS.Plant3D.
	return QAS.Plant3D.handleData(request, session)
