def handleSubmission(session, name, data, files, formContext, sessionContext, retry):
	if system.tag.readBlocking(["[default]BatteryLine/Line/SimEnabled"])[0].value:
		QAS.Line3D.simTick()